1. INTRODUCTION
===============

The ReSSCEMonTestSuite can be used to identify issues found with the CEMon for
OSG ReSS.  

 
2. DOWNLOAD THE TEST SUITE
==========================

The ReSSCEMonTestSuite can be downloaded from the following web page - 
https://twiki.grid.iu.edu/bin/view/ResourceSelection/CEMonTroubleshootingGuide

Extract the ReSSCEMonTestSuite-x.x.x.tar.gz
chmod a+x ReSSCEMonTestSuite-x.x.x/bin/*.sh

3. RUNNING THE TEST SUITE
=========================

To run all the tests in the test suite:

setup vdt
ReSSCEMonTestSuite-x.x.x/bin/ress-cemon-deployment-testsuite.sh

Summary of the test results will be shown on the stdout. Detailed log from 
running the tests can be found at /tmp/ReSSCEMonTestSuite.log

4. REPORTING ISSUES TO THE DEVELOPERS
=====================================

If you would like to contribute test cases to the test suite, please open a GOC
ticket directed to ress-support 