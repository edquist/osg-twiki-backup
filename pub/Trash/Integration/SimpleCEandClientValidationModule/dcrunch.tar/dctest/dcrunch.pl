#!/bin/env perl 
#
#############################

use Getopt::Std;
getopts('p:');

my $processID=$opt_p;

my $infile="rawdata_".$processID.".dat";
my $outfile="reduceddata_".$processID.".dat";
my $cmd=qq{/bin/grep 111 $infile > $outfile };
my $chkfile="/bin/ls -l $outfile";

for($i=0;$i<=10;$i++){
    sleep 2;
    print ".";
}
print "\n";

my $result=`$cmd`;
my $r0=`$chkfile`;
print $r0,"\n";


