/* serial.c -- serial trapezoidal rule
 *
 * Calculate definite integral using trapezoidal rule.
 * The function f(x) is hardwired.
 * Input: a, b, n.
 * Output: estimate of integral from a to b of f(x)
 *    using n trapezoids.
 *
 * See Chapter 4, pp. 53 & ff. in PPMPI.
 */

#include <stdio.h>

int main(int argc, char *argv[])
{
    char ch;
    double  integral;   /* Store result in integral   */
    float   a, b;       /* Left and right endpoints   */
    long    n;          /* Number of trapezoids       */
    double  h;          /* Trapezoid base width       */
    double  x;
    long    i;
    FILE    *fpin;      /* input file name            */
    FILE    *fpout;     /* output file name           */

    double f(double x);  /* Function we're integrating */

    if (argc < 3)
    {
        fprintf(stderr, "The program %s requires an input file name and an output file name as arguments to the command line\n", argv[0]);
        exit(1);
    }

    fprintf(stdout, "Input file name is: %s\n",argv[1]);
    fprintf(stdout, "Output file name is: %s\n",argv[2]);

    fpin=fopen(argv[1], "r");
    fpout=fopen(argv[2], "w");

 /*    printf("Enter a, b, and n\n");                 */
 /*    scanf("%f %f %ld", &a, &b, &n);                */
       fscanf(fpin,"%f %f %ld", &a, &b, &n);

    h = (b-a)/n;
    integral = (f(a) + f(b))/2.0;
    x = a;
    for (i = 1; i <= n-1; i++) {
        x = x + h;
        integral = integral + f(x);
    }
    integral = integral*h;

 /*    printf("With n = %ld trapezoids, our estimate\n",
 *       n);
 *     printf("of the integral from %f to %f = %f\n",
 *       a, b, integral);
 */

    fprintf(fpout,"With n = %ld trapezoids, our estimate\n", n);
    fprintf(fpout,"of the integral from %f to %f = %f\n", a, b, integral);

    fclose(fpin);
    fclose(fpout);
} /* main */


double f(double x) {
    double return_val;
    /* Calculate f(x).  Store calculation in return_val. */

    return_val = x*x;
    return return_val;
} /* f */
