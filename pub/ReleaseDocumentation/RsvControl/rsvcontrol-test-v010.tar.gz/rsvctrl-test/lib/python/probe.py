#!/bin/env python
# Probe.py
# Marco Mambelli
import os 
import sys    # sys.executable used for probe parameters
import commands
import copy
import shutil # copy to install probes

try:
    import logging
    log = logging.getLogger('osgrsv.rsvcontrol.probe')
except ImportError:
    # logging available starting python 2.3
    class LogFake:
        def _mywrite(mystr):
            print mystr
        _mywrite = staticmethod(_mywrite)
        def debug(self, mystr):
            _mywrite(mystr)
        def info(self, mystr):
            _mywrite(mystr)
        def warning(self, mystr):
            _mywrite(mystr)
        def error(self, mystr):
            _mywrite(mystr)
        log = LogFake()
        del LogFake

def getLocalHostName(static_name=[None]):
    if static_name[0]:
        return static_name[0]
    static_name[0] = os.getenv('HOSTNAME') # returns None if not existing
    if not static_name[0]:
        import socket
        static_name[0] = socket.gethostname()            
    return static_name[0]

def introspectProbe_old(fname, rsv=None):
    "Look for the probe file as absolute path, relative path, in the probe binary directory of RSV"
    if not os.path.isabs(fname):
        if os.path.isfile(fname):
            fname = os.path.abspath(fname)
        else:
            if rsv:
                fname = os.path.join(rsv.getBinDir(), fname)
            if not os.path.isfile(fname):
                log.warning("Unable to find probe file: %s", fname)
                return None
    if rsv:
        bindir = rsv.getBinDir()
    else:
        bindir = ''
    #ec, out = commands.getstatusoutput("PERL5LIB=%s:$PERL5LIB %s -l" % (bindir, fname))
    # -m all    could be omitted for probes with 1 metric (respecting LCG std)
    ec, out = commands.getstatusoutput("PERL5LIB=%s:$PERL5LIB %s -l -m all" % (bindir, fname))
    if ec<>0:
        log.warning("Unable to run the probe to get the description (%s)" % os.WEXITSTATUS(ec))
        log.info("Failed invocation: PERL5LIB=%s:$PERL5LIB %s -l -m all" % (bindir, fname))
        return None
    retv = {}
    if out:
        lines = out.split('\n')
        for i in range(len(lines)):
            if lines[i]=='EOT':
                break
            k, d = lines[i].split(':', 1)
            k = k.strip()
            if k == 'detailsdata':
                j = i
                while j<len(lines):
                    if lines[j]=='EOT':
                        break                    
                retv[k] = '\n'.join([d,] + lines[i:j])
                break
            retv[k] = d.strip()
    return retv

def introspectProbes(fname, rsv=None):
    """Look for the probe file as absolute path, relative path, in the probe binary directory of RSV
    One file may contain multiple probes (LCG would require only one)
    """
    if not os.path.isabs(fname):
        if os.path.isfile(fname):
            fname = os.path.abspath(fname)
        else:
            if rsv:
                fname = os.path.join(rsv.getBinDir(), fname)
            if not os.path.isfile(fname):
                log.warning("Unable to find probe file: %s", fname)
                return None
    if rsv:
        bindir = rsv.getBinDir()
    else:
        bindir = '.'
    cmd = "PERL5LIB=%s:$PERL5LIB %s -l -m all" % (bindir, fname)
    ec, out = commands.getstatusoutput(cmd)
    if ec<>0:
        log.warning("Unable to run the probe to get the description (%s)" % os.WEXITSTATUS(ec))
        log.debug("Failed command: %s" % (cmd,))
        return None
    retlist=[]
    retv = {}
    if out:
        lines = out.split('\n')
        start_detailsdata=-1
        for i in range(len(lines)):
            if lines[i]=='EOT':
                if start_detailsdata>0:
                    retv['detailsdata'] = '\n'.join([d,] + lines[start_detailsdata:i])
                retlist.append(retv)
                start_detailsdata=-1
                retv={}
                continue
            if start_detailsdata>=0:
                continue
            k, d = lines[i].split(':', 1)
            k = k.strip()
            if k == 'detailsdata':
                #TODO check output: should it be i or i+1?
                start_detailsdata=i
                continue
            retv[k] = d.strip()
        if retv:
            #output ended and last EOT was missing 
            if start_detailsdata>0:
                retv['detailsdata'] = '\n'.join([d,] + lines[start_detailsdata:i])
            retlist.append(retv)
    return retlist

# returns only the first probe, should not be used if probes do not follow LCG std
def loadProbeFromFile_old(fname, rsv, uri=None, uridict=None, options_=None):
    "Returns a probe form the given probe file"
    val = introspectProbe(fname, rsv)
    if not val:
        log.error("Unable to load probe: introspection failed")
        return None
    ptype = None
    try:
        ptype = val['probeType']
    except KeyError:
        try:
            ptype = val['serviceType']
        except KeyError:
            pass
    if not ptype:
        log.error("Unable to load probe: probeType and serviceType not defined")
        return None
    if uridict:
        try:
            uri = uridict[ptype]
        except KeyError:
            pass
    probe = getProbe(ptype, fname, uri, ptype, rsv=rsv, metricName=val['metricName'], metricType=val['metricType'], serviceType=val['serviceType'])
    # add remaining values:
    try:
        values = val['metricInterval'].split()
        probe.setCronValues(values)
    except KeyError:
        pass
    try:
        probe.enableByDefault = val['enableByDefault']
    except KeyError:
        pass
    # metricValuesExtra Excluding: metricName, metricType, probeType, serviceType, metricInterval, enableByDefault
    probe.metricValuesExtra = {}
    for i in val.items():
        if i[0] in ['metricName', 'metricType', 'probeType', 'serviceType', 'metricInterval', 'enableByDefault']:
            continue
        probe.metricValuesExtra[i[0]] = i[1]
    return probe

def loadAllProbesFromFile(fname, rsv, uri=None, uridict=None, options_=None):
    """Returns all probes form the given probe file
    NB in LCG there should be only one probe per file
    """
    vallist = introspectProbes(fname, rsv)
    if not vallist:
        log.error("Unable to load probe: introspection failed")
        return None
    retlist = []
    for val in vallist:
        ptype = None
        try:
            ptype = val['probeType']
        except KeyError:
            try:
                ptype = val['serviceType']
            except:
                pass
        if not ptype:
            log.error("Unable to load probe: probeType and serviceType not defined")
            continue
        if not uri and uridict:
            try:
                uri = uridict[ptype]
            except KeyError:
                pass
        probe = getProbe(ptype, fname, uri, ptype, rsv=rsv, metricName=val['metricName'], metricType=val['metricType'], serviceType=val['serviceType'], options=options_)
        # add remaining values:
        try:
            values = val['metricInterval'].split()
            probe.setCronValues(values)
        except KeyError:
            pass
        try:
            probe.enableByDefault = val['enableByDefault']
        except KeyError:
            pass
        # metricValuesExtra Excluding: metricName, metricType, probeType, serviceType, metricInterval, enableByDefault
        probe.metricValuesExtra = {}
        for i in val.items():
            if i[0] in ['metricName', 'metricType', 'probeType', 'serviceType', 'metricInterval', 'enableByDefault']:
                continue
            probe.metricValuesExtra[i[0]] = i[1]
        retlist.append(probe)
    return retlist

class Probe(object):
    """Probe class to group Probe configuration and start, stop, ...
    
    Probes are executables, normally Perl scripts, part of the RSV infrastructures
    They are (should be) developed following LCG specification:
    https://twiki.cern.ch/twiki/bin/view/LCG/GridMonitoringProbeSpecification
    They can be invoked as 'PERL5LIB=$OSG_RSV_LOCATION/bin/probes:$PERL5LIB $probe -l -m all' 
    Only one metric can be returned (by specification), therefore -m all makes no sense
    to discover supported metrics (description):
    serviceType: SRM
    metricName: org.glite.SRM-getFile
    metricType: status
    - 
    """        
        
    # Keep linear MRO
    SUBMIT_PARAM_EXECUTABLE = "bin/probes/probe_wrapper.pl"
    SUBMIT_PARAM_ENVIRONMENT = "PATH=$PATH;PERL5LIB=$OSG_RSV_LOCATION/bin/probes:$PERL5LIB;VDT_LOCATION=$VDT_LOCATION"
    SUBMIT_PARAM_CRON = { "CronHour": "*/2",
                          "CronMonth": "*",
                          "CronDayOfMonth": "*",
                          "CronDayOfWeek": "*",
                      }
    SUBMIT_PARAM_OTHER = { "Universe": 'local',
                           #"Arguments": '',
                       }
    SUBMIT_DEFAULT_ARGS = ''

    #vars for editor
    name = ''
    type = ''
    rsvlocation = ''
    urilist = []
    extra_spec_content = ''
    submit_params = {}
    
    def __init__(self, name, uriliststring, type, rsv=None, metricName=None, 
                 serviceType=None, metricType='status', extra_args=None,
                 options=None):
        # retrieving and storing options form the command line
        # TODO: select only what will be used?
        # better way to pass probe options?
        # used in _aux_getCLParameters getCLParameters (also by subclasses)
        self.options = options
        if name:
            self.name = name.strip()
        else:
            self.name = name
        if not metricName:
            self.metricName = self.name
        else:
            self.metricName = metricName.strip()
        self.probeType = type
        if not serviceType:
            self.serviceType = type
        else:
            self.serviceType = serviceType
        self.metricType = metricType
        self.enableByDefault = False
        self.metricValuesExtra = {} # Excluding: metricName, metricType, probeType, serviceType, metricInterval, enableByDefault
        self.rsv = rsv
        if rsv:
            self.rsvlocation = rsv.getLocation()
            self.rsvperllibdir = rsv.getPerlLibDir()
        else:
            self.rsvlocation = ''
            self.rsvperllibdir = ''
        #self.extra_spec_content = ''
        self.local = False
        if not uriliststring:
            self.urilist = []
        else:
            # convert to lowercase (case not important in URI)
            # avoids useless duplicates
            self.urilist = [i.lower() for i in uriliststring.split()]
        self.submit_params = copy.copy(Probe.SUBMIT_PARAM_CRON)
        self.submit_params.update(Probe.SUBMIT_PARAM_OTHER)
        self.executable = Probe.SUBMIT_PARAM_EXECUTABLE
        # should this be used or just getCLParams?
        self.clparams = Probe.SUBMIT_DEFAULT_ARGS
        self.setCronValues('*-*/2-*-*-*'.split('-'))   # inport from rsvcontrol? (OPTIONS_DEFAULT.crontime.split('-'))
        #self.submit_params["Executable": os.path.join(location, bin/probes/probe_wrapper.pl) # "$OSG_RSV_LOCATION/bin/probes/probe_wrapper.pl",
        if options:
            #TODO: check these options
            #condor-cron is always using local universe!
            #if options.jobuniverse:
            #    self.submit_params["Universe"] = options.jobuniverse
            """
            if options.crontime: # self.submit_params["Cron..."]
                self.setCronValues(options.crontime.split("-"))
            # command line options
            if options.probe_voname:
                self.clparams += " --virtual-organization %s" % (options.probevoname,)
            if options.probe_verbose:
                self.clparams += " --verbose"      
            if options.probe_localtime:
                self.clparams += " --print-local-time"
            """
            action_dict = { 'crontime': 'self.setCronValues(options.crontime.split("-"))',
                            'probe_voname': 'self.clparams += " --virtual-organization %s" % (options.probe_voname,)',
                            'probe_verbose': 'self.clparams += " --verbose"',
                            'probe_localtime': 'self.clparams += " --print-local-time"',
                            }
            for i in action_dict.keys():
                try: 
                    if options.__dict__[i]:
                        exec(action_dict[i])
                except KeyError:    # if evaluated would be AttributeError
                    log.debug("No %s in probe options" % (i,))
        if extra_args:
            self.clparams += extra_args
            
    def _loadProbeMetrics(self):
        return

    def setCronValues(self, values):
        "values array follows the cron (5) standard"
        if not values or len(values)<>5:
            # Should control better for valid values (e.g. inspect each value)?
            log.warning("Invalid cron period setting (%s), ignored" % (values,))
            return
        self.submit_params["CronMinute"] = values[0]
        self.submit_params["CronHour"] = values[1]
        self.submit_params["CronDayOfMonth"] = values[2]
        self.submit_params["CronMonth"] = values[3]
        self.submit_params["CronDayOfWeek"] = values[4]
        return

    def getMetricInterval(self, novalue=None):
        rets = ""
        for i in ("CronMinute", "CronHour", "CronDayOfMonth", "CronMonth", "CronDayOfWeek"):
            try:
                tmp = self.submit_params[i]
            except KeyError:
                if novalue:
                    tmp = novalue
                else:
                    raise KeyError(i)
            rets += "%s " % tmp
        
        return rets[:-1]
    
    def addURI(self, uri):
        if not self.urilist:
            self.urilist = [uri]
        else:
            self.urilist.append(uri)
            
    def getType(self):
        """Returns Probe Type
        probeType. It may be different from serviceType (but often it is the same). It is different from metricType (e.g. "service")
        """
        return self.probeType
    
    def getName(self):
        """Returns the probe name
        Probe name. It is not the file name. It may be different from the metricName (but often it is the same). 
        """
        return self.name
    
    #def _fixProbeSuffix(self, instr):
    def _fixProbeSuffix(instr):
        "Adjust the probe suffix"
        if not instr.endswith('-probe'):
            instr += "-probe"
        return instr
    _fixProbeSuffix=staticmethod(_fixProbeSuffix)

    def getProbe(self):
        "Return the absolute path of the probe"
        pname = self.name
        if pname and pname[0]==['/']:
            return pname
        pname = self._fixProbeSuffix(pname)
        return os.path.join(self.rsvperllibdir, pname)

    def getExecutable(self):
        "Return the wrapper script usd to run the probes"
        executable = self.executable
        if executable and executable[0]==['/']:
            return executable
        #TODO rsvlocation or PerlLibDir?
        return os.path.join(self.rsvlocation, executable)

    def getLocalUniqueName(self, uri=None):
        """Name as '%(host)s__%(key)s', where key = "%s@%s" % (basename, metricName)
        file basename (from getProbe)
        TODO: Concern about host from URI: are host unique or should the full URI be used?
        """
        name = "%s__%s@%s" % (self._getonlyhost(uri), os.path.basename(self.getProbe()), self.metricName)
        return name

    def getKey(self):
        name = "%s@%s" % (os.path.basename(self.getProbe()), self.metricName)
        return name

    def getLocation(self):
        # either RSV or RSVLOCATION
        return self.rsvlocation
    
    def _aux_getCLParameters(self, uri):
        "auxiliary function to return CL parameters as string"
        outstr = ""
        #extra options files
        for spec_file in (os.path.join(self.rsv.getSpecDir(), 'global-specs', "%s.spec" % (self.getKey(),)),
                          os.path.join(self.rsv.getSpecDir(), "%s" % (self._getonlyhost(uri),), "%s.spec" % (self.getKey(),))):
            if os.path.isfile(spec_file):
                tmp = open(spec_file).readlines()
                if tmp: 
                    # replace the newlines with spaces because these are command line arguments
                    outstr += ' '.join(tmp.split('\n'))
            else: # should not happen, files created in installation
                # fails if directory no there
                try:
                    open(spec_file,'w').close()  # make a blank file for people to add to if they want
                except IOError:
                    dirname = os.path.dirname(spec_file)
                    if not os.path.exists(dirname):
                        os.makedirs(dirname)
                        open(spec_file,'w').close()
                    else:
                        raise IOError("Unable to create %s" % spec_file)                            
        #retrieve params from file
        metric = self.metricName
        if metric:
            if outstr.find("-m %s" % (metric,)) < 0:
                outstr += " -m %s" % (metric,)
        outstr += self.clparams

        # parameters from options:
        #TODO: replace options
        #global options
        options = self.options
        if options:
            """
            if options.probe_voname:
                ourstr += " --virtual-organization "+options.probe_voname
            if options.probe_verbose:
                ourstr += " --verbose"
            if options.probe_localtime:
                ourstr += " --print-local-time"
                """
            action_dict = { 'probe_voname': 'outstr += " --virtual-organization %s" % (options.probe_voname,)',
                            'probe_verbose': 'outstr += " --verbose"',
                            'probe_localtime': 'outstr += " --print-local-time"',
                            }
            for i in action_dict.keys():
                try: 
                    if options.__dict__[i]:
                        exec(action_dict[i])
                except KeyError:    # if evaluated would be AttributeError
                    log.debug("No %s in probe options" % (i,))

        """
      ## If extra specs are passed, then append them
      $local_submit_params{Arguments} .= " $extra_spec_contents" if (defined($extra_spec_contents));
"""
        # Add in additional flags if it is not a local probe
        # Handle this redefining the function in the subclass ProbeLocal or ProbeNotLocal?
        if not self.local:
            try:
                if options.gratia and outstr.find("--ggs")<0:
                    # Find python, so that the probes can put it in shebang line
                    # If we can't find python, we probably don't want these scripts to accumulate
                    if sys.executable:
                        #TODO: ? add gratia grid type? grid_type, rsvgratiafile
                        outstr += " --ggs --gsl %s/output/gratia --python-loc %s" % (self.rsvlocation, sys.executable)
                    else:
                        warning = "Gratia output cannot be enabled for OSG-RSV because python cannot be found.\n"
                        post_install_log(warning)
                        log.warning(warning)
            except AttributeError:
                # option has no gratia attribute
                pass
            ## Check whether we need to add the "--uri" flag
            if outstr.find('--uri') < 0:
                #          unless ($local_submit_params{Arguments} =~ /\-\-uri /) {
                outstr += " --uri %s" % (uri,)
            # Check if we need to add a --proxy argument
            #TODO: ? service proxy is handled automatically?
            try:
                if options.proxy_file:
                    outstr += " --proxy %S" % (options.proxy_file,)
            except AttributeError:
                # option has no attribute proxy_file
                pass
        # probe name added in caller (getCLParameters)
        return outstr
        
    def getCLParameters(self, uri=None):
        """Return CL parameters as string
        use self.metricName, self.getProbe, uri, options
        """
        outstr = self._aux_getCLParameters(uri)
        # The probe name is the first argument, because we need to tell the wrapper what probe to execute
        outstr = "%s %s" % (self.getProbe(), outstr)
        return outstr

    def _getonlyhost(uri):
        # LocalProbes allow no uri and the host is localhost
        if not uri: # move the functionality in functions where used? redefine for LocalProbes?
            uri = getLocalHostName()
        # if URI string passed, assume [method://]host.domain[:port][/url]
        start = uri.find('://')
        dst = uri
        if start>=0:
            dst = uri[start+3:]
        end = dst.find(':')
        if end<0:
            end = dst.find('/')
        if end<0:
            return dst
        return dst[:end]
    _getonlyhost = staticmethod(_getonlyhost)

    def configure(self, probe, uri, host, extra_spec_contents):
        """Probe configuration
        - create extra spec file
        """        
        return
    
    def configureTest(self, uri, force=False, enable=False, disable=False, value=None):
        """Configure a test:
        If no additional value is provided will use self.enableByDefault (from the probe itself) to configure as default
        - enable: force the enabling of the probe
        - disable: force the disabling of the probe (overrides enable)
        - value: specifies the values of the configuration including enable/disable:
                [ enabled(boolean), 5 cron values (minute, hour, domonth, month, doweek)]
                (overrides enable and disable)
        - change the test tun parameters (metrics)
        - installTest = add submit file or 
        - removeRest = delete submit file depending on configuration
        """
        #TODO: check value of value if provided
        #TODO: role of force not clear, not used
        if not self.rsv:
            log.error("No OSG RSV defined. Probe cannot be installed or configured.")
        host = self._getonlyhost(uri)
        log.info("Changing configuration for RSV probes of type %s\n\t for URI: %s (host: %s)" %
                 (self.name, uri, host))
        if not self.rsv.metricsFileFix(host):
            log.error("Bad metrics file for host %s, ckeck it manually" % (host,))            
            return
        if not value:
            value = self.getMetricInterval().split()
            to_be_enabled = self.enableByDefault
            if enable:
                to_be_enabled = True
            if disable:
                to_be_enabled = False
            if to_be_enabled:
                value.insert(0, True)
                self.installTest(uri)
                #self.startTest(uri)
            else:        
                value.insert(0, False)
                self.removeTest(uri)
                #self.stopTest(uri)
                #TODO: remove sub file?
        self.rsv.metricsFileUpdate(host, self.getKey(), value)
        return
    
    def configureTestAll(self, uri_list):
        """Configure all tests for this probe:
        using configuration file
        """
        for i in uri_list:
            self.configureTest(i)
        return

    def removeTest(self, uri):
        """Remove a test
        - remove submit file
        """
        if not self.rsv:
            log.error("No RSV defined. Probe cannot be installed or configured.")
            return
        lun = self.getLocalUniqueName(uri)
        log.info("Removing .sub files for RSV probe of type %s\n\t for URI: %s (LUN: %s)" %
                 (self.name, uri, lun))
        subm = self.rsv.getSubmitter()
        subm.cleanupById(lun, self.rsv)
        return

    def installTest(self, uri, test_only=False):
        """Installs a test
        - install submit file
        """
        if not self.rsv:
            log.error("No RSV defined. Probe cannot be installed or configured.")
            return
        host = self._getonlyhost(uri)
        log.info("Creating .sub files for RSV probes of type %s\n\t for URI: %s (host: %s)\n" %
                 (self.name, uri, host))
        #TODO: go through RSV, no direct CondorSubmitter self.rsv.getSubmitter()
        subm = self.rsv.getSubmitter()
        subm.prepare(self, self.rsv, uri, cron_submission=(not test_only))
        
        # extra options, touch file
        spec_file = os.path.join(self.rsv.getSpecDir(), "%s" % (host,), "%s.spec" % (self.getKey(),))
        if not os.path.exists(spec_file):
            log.info("Adding spec file (for metric extra options): %s" % (spec_file,))
            open(spec_file,'w').close()  # make a blank file for people to add to if they want
        return    

    def install(self):
        """"Install the probe
        - copy the file in the RSV bin directory
        - invoke configure
        """
        probefile = os.path.abspath(self.getProbe())
        if not self.rsv:
            log.error("No RSV defined. Probe cannot be installed or configured.")
            return
        if not os.path.dirname(probefile) == os.path.abspath(self.rsv.getBinDir()):
            # probe not in the RSV binary dir
            try:
                shutil.copy(probefile, os.path.abspath(self.rsv.getBinDir()))
                log.info("Probe file %s copied in OSG-RSV bin directory (%s)." % 
                         (probefile, os.path.abspath(self.rsv.getBinDir())))
            except:
                log.error("Unable to install the probe in RSV.")
                log.info("Probe file %s could not be copied in OSG-RSV bin directory (%s)." % 
                         (probefile, os.path.abspath(self.rsv.getBinDir())))
                return
        # extra options, touch file
        spec_file = os.path.join(self.rsv.getSpecDir(), 'global-specs', "%s.spec" % (self.getKey(),))
        if not os.path.exists(spec_file):
            log.info("Adding spec file (for probe extra options): %s" % (spec_file,))
            open(spec_file,'w').close()  # make a blank file for people to add to if they want
        #self.configure()
        return

    def startTest(self, uri):
        """Start probe (add it to condor-cron)
        """
        subm = self.rsv.getSubmitter()
        subm.submit(self, self.rsv, uri)
        return
    
    def start(self):
        """Start probe (add it to condor-cron)
        """
        subm = self.rsv.getSubmitter()
        #TODO: imlement
        log.error("Not implemented. Start all the probes")
        raise Exception("Incomplete method")
        #subm.submit(self, self.rsv)
        return

    def stopTest(self, uri):
        """Stop probe (remove it from condor-cron)
        """
        subm = self.rsv.getSubmitter()
        subm.stopByID(self.getLocalUniqueName(uri), self.rsv)
        return

    def stop(self):
        """Stop probe (remove it from condor-cron)
        """
        subm = self.rsv.getSubmitter()
        #TODO: imlement
        log.error("Not implemented. Stop all the probes")
        raise Exception("Incomplete method")
        #subm.stop(self, self.rsv, uri)
        return

    def status(self, uri=None):
        """List probe status in RSV:
        UNDEFINED, UNINSTALLED, INSTALLED (and not configured), (configured,) DISABLED, ENABLED
        """
        status = "UNDEFINED"
        if not self.rsv:
            return status
        status = "UNINSTALLED"
        if not os.path.isfile(os.path.join(self.rsv.getBinDir(), os.path.basename(self.getProbe()))):
            return status
        # executable file there
        status = "INSTALLED"
        if uri:
            urilist = [uri]
        else:
            urilist = self.urilist
        #passed = False
        met = None
        for u in urilist:
            met = self.rsv.metricsFileRetrieve(u, self.getKey())
            if met:
                #passed = True
                break
        if not met:
            log.warning("Probe %s is installed but probably misconfigured" % self.getLocalUniqueName(uri)) 
            return status #"UNDEFINED"
        try:
            if met['enable']:
                return "ENABLED"
            else:
                return "DISABLED"
        except KeyError:
            # Bad file format
            pass
        log.warning("Irregular status file")
        return "UNDEFINED"

    def isEnabled(self, uri):
        """Returns if a probe is enabled for a specific URI
        A probe/uri is enabled if:
        - the metric files reports the probe enabled
        - the submitted job is queued or running fine 
        This function is not checking:
        - if there is recent output from the probe (is not wwre of the supposed period)
        - if the output is correct (a probe could be running but return wrong output, it is still enabled)
        """
        if self.status(uri) == 'ENABLED':
            # check status of submitted job
            subm_status = self.submission_status(uri)
            if self.rsv.getSubmitter().isHealthy(subm_status):
                return True
        return False
    
    # Undefined, disabled, enabled, installed, uninstalled, undefined
    def submission_status(self, uri, format='brief', probe_test=False):
        """Submitter (Condor) status of the job.
        Uses LocalUniqueID to get the status from the submitter defined in RSV
        Check the Submitter for possible status formats.
        """
        subm = self.rsv.getSubmitter()
        retv = subm.listByID(self.getLocalUniqueName(uri), self.rsv, format, probe_test=probe_test)
        return retv
    
    def enable(self, uri):
        """Enables the probe
        """
        self.install()
        self.configureTest(uri, enable=True)
        self.startTest(uri)
        log.info("Metric %s enabled" % (self.getLocalUniqueName(uri),))
        return

    def disable(self, uri):
        self.stopTest(uri)
        # remove line from configuration file
        self.configureTest(uri, disable=True)
        log.info("Metric %s disabled" % (self.getLocalUniqueName(uri),))
        return

    def test(self, uri):
        "Probe is executed and output returned"
        fname = self.getExecutable()
        if not os.path.isabs(fname):
            if os.path.isfile(fname):
                fname = os.path.abspath(fname)
            else:
                if rsv:
                    fname = os.path.join(rsv.getBinDir(), fname)
                if not os.path.isfile(fname):
                    log.error("Unable to find probe file: %s", fname)
                    return
        if self.rsv:
            bindir = self.rsv.getPerlLibDir()
            vdtdir = ";VDT_LOCATION=%s" % (self.rsv.getVdtLocation(),)
        else:
            bindir = '.'
            vdtdir = ""
        # probe.getCLParameters()
        cmd = "PERL5LIB=%s:$PERL5LIB%s %s %s" % (bindir, vdtdir, fname, self.getCLParameters(uri))
        ec, out = commands.getstatusoutput(cmd)
        log.info("Test command: %s" % (cmd,))
        if ec<>0:
            log.error("Unable to run the probe (%s)" % os.WEXITSTATUS(ec))
            log.debug("Failed command output: %s" % (out,))
            return ""
        if not out:
            log.warning("No output returned.")
            return ""
        return out
    
    def full_test(self, uri):
        "Execute a full test inside the OSG-RSV infrastructure"
        self.install()
        #no configuratin necessary (configuration sets cron timing and enabled/disabled status)
        #skip self.configureTest(uri, enable=True), invoking installTest directly to prepare submit file
        self.installTest(uri, True)
        subm = self.rsv.getSubmitter()
        log.info("Testing metric %s" % (self.getLocalUniqueName(uri),))
        subm.submit_immediate(self, self.rsv, uri)
        #skip self.configureTest(uri, disable=True)
        return
    
    def list(self, uri, format='local'):
        """List probe status
        Dismbiguation unction using status or submission_status depending on the format
        """
        if format=='local':
            return self.status(uri)
        else:
            return self.submission_status(uri, format)
    
    def diagnostic(self, uri, verbose=False, prefix="", probe_test=False):
        """Return a string with diagnostic information
        """
        import time
        p_exe = self.getExecutable()
        p_exe_date = "-na-"
        if os.path.isfile(p_exe):
            p_exe_date = time.ctime(os.path.getmtime(p_exe))
        outstr = "%sName %s, Verision %s, File name (mtime): %s(%s)\n" % (prefix, self.name, self.getVersion(), p_exe, p_exe_date)
        outstr += "URI: %s" % (uri,) #All URIs ('\n'.join(self.urilist),)
        outstr += "Local Status: %s" % (self.status(uri),)
        outstr += "Submission Status: %s" % (self.submission_status(uri, 'brief', probe_test),)
        # Diagnostic euristics?
        # - Try to parse files and infer probe status?
        #  - hold status in log file
        #  - no recent out/err file
        #  - err file not empty
        #  - CRITICAL string in out
        if verbose:
            outstr += "Full submision status:\n%s" % (self.submission_status(uri, 'full'))
            for i in ('out', 'err', 'log'):
                outstr += "Job %s:\n%s" % (i, self.submission_status(uri, i, probe_test))
        return outstr
    
    def describe(self, verbose=False, prefix=""):
        #
        outstr = "%sPROBE: Name %s, URI %s\n" % (prefix, self.name, '\n'.join(self.urilist))
        outstr += "%s metricName: %s, metricType: %s, probeType: %s, serviceType: %s, metricInterval: %s, enableByDefault: %s\n" % (
            prefix, self.metricName, self.metricType, self.probeType, self.serviceType, self.getMetricInterval('?'), self.enableByDefault)
        if self.metricValuesExtra:
            outstr += "%s Introspected parameters: " % (prefix,)
            for i in self.metricValuesExtra.items():
                outstr += "%s: %s " % (i[0], i[1])
            outstr += "\n"
        outstr += "%s File: %s, Wrapper: %s" % (prefix, self.getProbe(), self.getExecutable())
        if verbose:
            if not self.rsv:
                outstr += "%s No RSV" % (prefix,)
            else:
                outstr += "%s RSV description:\n" % (prefix,) + self.rsv.describe(prefix=prefix+"  ")
        return outstr
    
class ProbeTest(Probe):
    """Simple probe
    """
    def __init__(self, name='test', uri=None, type='Test', *args, **kwrds):
        Probe.__init__(self, name, uri, type, *args, **kwrds)
        
    def makeProbeFile(fname='test'):
        import stat # used to manipulate file mode
        if not os.path.isabs(fname):
            fname = Probe._fixProbeSuffix(fname)
        try:
            log.info("Creating a test probe in file: "+fname)
            fp = open(fname, 'w')
            fp.write("""#!/bin/sh
cat << EOF
serviceType: OSG-CE-General
metricName: org.osg.general.osg-directories-CE-permissions
metricType: status
probeType: OSG-CE
enableByDefault: true
metricInterval: 5 6 * * *
EOT
""")
            fp.close()
            fmode = os.stat(fname).st_mode | stat.S_IEXEC
            os.chmod(fname, fmode)
        except IOError:
            log.error('Unable to write probe file: '+fname)
            return None
        return fname
    makeProbeFile = staticmethod(makeProbeFile)

    def makeProbe(name='test', rsv=None, uri=''):
        fname = ProbeTest.makeProbeFile(name)
        if fname:
            retp = loadProbeFromFile(fname, rsv, uri)
        else:
            retp = ProbeTest()
        return retp
    makeProbe = staticmethod(makeProbe)
    
probe_dict = {}
probe_dict = {'Probe': Probe,
              'ProbeTest': ProbeTest}                
                
class ProbeLocal(Probe):
    """Local Probes
    """
    def __init__(self, name, uri=None, type='OSG-Local-Monitor', *args, **kwrds):
        if not uri:
            uri = getLocalHostName()
        #super(ProbeLocal, self).__init__(name, uri)
        Probe.__init__(self, name, uri, type, *args, **kwrds)
        self.local = True 
        #self.urilist initialized to localhost 

    #def _fixProbeSuffix(self, executable):
    def _fixProbeSuffix(executable):
        "Adjust the probe suffix"
        if not executable.endswith('-local-probe'):
            if not executable.endswith('-local'):
                executable += "-local"
            executable += "-probe"
        return executable
    _fixProbeSuffix=staticmethod(_fixProbeSuffix)

    def addURI(self, uri):
        # TODO: how are URI handled in local probes?
        # currently local probes are ignoring URI
        # Local probes use localhost name for the LocallyUniqueName (e.g. used for metrics file name)
        log.debug("Ignoring request to add uri %s to local probe %s (uri: %s)" % (uri, self.getKey(), self.urilist))
        return
    
probe_dict['local'] = ProbeLocal
probe_dict['OSG-Local-Monitor'] = ProbeLocal

class ProbeNonLocal(Probe):
    """Base class for non local probes
    """ 
    def getCLParameters(self, uri=None): #TORM:, metric=None):
        "Return CL parameters as string"
        outstr = self._aux_getCLParameters(uri) #TORM:, metric)
        #TODO: replace options
        options = self.options
        if options:
            try:
                if (options.gratia and outstr.find('--ggs') < 0):
                    # Find python, so that the probes can put it in shebang line
                    #if($path) { # If we can't find python, we probably don't want these scripts to accumulate
                    if sys.executable:
                        outstr += " --ggs --gsl %s/output/gratia --python-loc %s" % (self.rsvlocation, sys.executable)
                    else:
                        warning = "Gratia output cannot be enabled for OSG-RSV because python cannot be found.\n"
                        post_install_log(warning)
                        log.warning(warning)
            except AttributeError:
                log.debug("No gratia attribute in options")
            # Check if we need to add a --proxy argument
            try:
                if options.proxy_file:
                    outstr += " --proxy %S" % (options.proxy_file,)
            except AttributeError:
                log.debug("No proxy_file attribute in options")
        ## Check whether we need to add the "--uri" flag
        if outstr.find('--uri') < 0:
            outstr += " --uri %s" % (uri,)
        # The probe name is the first argument, because we need to tell the wrapper what probe to execute
        outstr = "%s %s" % (self.getProbe(), outstr)
        return outstr


#probe_dict['nonlocal'] = ProbeNonLocal

class ProbeCE(ProbeNonLocal):
    def __init__(self, name, uri, type='OSG-CE', *args, **kwrds):
        if not type=='OSG-CE':
            log.warning('Wrong Probe invoked: %s instead of OSG-CE' % (type,))
        Probe.__init__(self, name, uri, type, *args, **kwrds)
probe_dict['OSG-CE'] = ProbeCE

class ProbeGUMS(ProbeNonLocal):
    def __init__(self, name, uri, type='OSG-GUMS', *args, **kwrds):
        if not type=='OSG-GUMS':
            log.warning('Wrong Probe invoked: %s instead of GUMS' % (type,))
        Probe.__init__(self, name, uri, type, *args, **kwrds)
probe_dict['OSG-GUMS'] = ProbeGUMS

class ProbeGridFTP(ProbeNonLocal):
    def __init__(self, name, uri, type='OSG-GridFTP', *args, **kwrds):
        if not type=='OSG-GridFTP':
            log.warning('Wrong Probe invoked: %s instead of GridFTP' % (type,))
        Probe.__init__(self, name, uri, type, *args, **kwrds)
probe_dict['OSG-GridFTP'] = ProbeGridFTP

class ProbeSRM(ProbeNonLocal):
    def __init__(self, name, uri, type='OSG-SRM', *args, **kwrds):
        if not type=='OSG-SRM':
            log.warning('Wrong Probe invoked: %s instead of SRM' % (type,))
        Probe.__init__(self, name, uri, type, *args, **kwrds)
probe_dict['OSG-SRM'] = ProbeSRM

class ProbeSE(ProbeNonLocal):
    def __init__(self, name, uri, type='OSG-SE', *args, **kwrds):
        if not type=='OSG-SE':
            log.warning('Wrong Probe invoked: %s instead of OSG-CE' % (type,))
        #super(ProbeLocal, self).__init__(name, uri)
        Probe.__init__(self, name, uri, type, *args, **kwrds)
probe_dict['OSG-SE'] = ProbeSE


def getProbe(probetypename, *args, **kwrds):
    """Returns one object having as class one of the valid Probe classes.
    If the type is not available a test probe is returned.
    """
    retv = None
    try:
        rett = probe_dict[probetypename]
        retv = rett(*args, **kwrds)
    except KeyError:
        log.warning("Probe of type %s not found (%s), returning ProbeTest" % (probetypename, probe_dict.keys()))
        rett = ProbeTest
        retv = rett(*args, **kwrds)
        #retv = rett(*((None,) + args), **kwrds)
    return retv

def getProbeTypeList():
    "Returns a list of the available job types"
    return probe_dict.keys()

################


def main():
    #TODO: use it for testing
    # Main
    return

    
if __name__ == "__main__":
    main()