#!/bin/env python
# osgrsv.py
# Marco Mambelli <marco@hep.uchicago.edu>

import os
import commands  # used to get OSG RSV version 

from probe import loadAllProbesFromFile

try:
    import logging
    log = logging.getLogger('osgrsv.rsvcontrol.osgrsv')
except ImportError:
    # logging available starting python 2.4
    class LogFake:
        def _mywrite(mystr):
            print mystr
        _mywrite = staticmethod(_mywrite)
        def debug(self, mystr):
            _mywrite(mystr)
        def info(self, mystr):
            _mywrite(mystr)
        def warning(self, mystr):
            _mywrite(mystr)
        def error(self, mystr):
            _mywrite(mystr)
        log = LogFake()
        del LogFake

    
def findPathOSG():
    # find the path to OSG root directory
    osgp = os.getenv('OSG_LOCATION')
    if not osgp:
        osgp = os.getenv('VDT_LOCATION')
    if not osgp:
        osgp = ''
    return osgp    

def getConfigOSG(fname, static_config=[None]):
    if static_config[0]:
        return static_config[0]
    import ConfigParser
    # read and parse configureosg.ini
    try:
        fp = open(fname)
    except:
        #Error, fatal
        log.error("Unable to open OSG configuration file " + fname)
        #sys.exit(1)
        return None
    # cp = ConfigParser.SafeConfigParser(defaults_dic) 
    cp = ConfigParser.SafeConfigParser()
    try:
        cp.readfp(fp)
    except:
        log.error("Error parsing the OSG configuration file " + fname)
        #sys.exit(-1)
        return None
    static_config[0] = cp
    return cp
"""
osgconfig = {} # ordr not importsnt
    for i in cp.sections():
        itemlist.append((i, cp.items(i)))
    return cp.sections, itemlist
"""

# The name is used as name of the server and for the 
# root directory (VDT_LOCATION+OSGRSV_NAME)
OSGRSV_NAME = "osg-rsv"

class OSGRSV:
    DEFAULT_CONFIG_ENTRY = { "enable": True,
                             "CronMinute": "*",
                             "CronHour": "*/2",
                             "CronMonth": "*",
                             "CronDayOfMonth": "*",
                             "CronDayOfWeek": "*",
                         }
    DEFAULT_CONFIG_FILE = "config/rsv-config.pytxt"
    DEFAULT_CONFIG = {
        'username': 'rsvuser',
        'proxy': '/tmp/x509_u<uid>',
        'rsv_use_service_cert': False,
        'rsv_proxy_file': '/tmp/rsvproxy',
        'rsv_cert_file': '/etc/grid-security/rsvcert.pem',
        'rsv_key_file': '/etc/grid-security/rsvkey.pem',
    }
    
    def __init__(self, vdtlocation=None, config=None, user=None):
        self.name = OSGRSV_NAME
        if vdtlocation:
            self.vdtlocation = os.path.abspath(vdtlocation)
        else:
            self.vdtlocation = findPathOSG()
        if not self.vdtlocation:
            log.warning("Unable to determine VDT_LOCATION")
            self.vdtlocation = ''
        self.location = os.path.join(self.vdtlocation, self.name) # "$VDT_LOCATION/osg-rsv";
        self.metrics_loc = os.path.join(self.location, "config") #"$OSG_RSV_LOCATION/config";
        #self.probe_spec_loc = os.path.join(self.location, "specs") #"$OSG_RSV_LOCATION/specs";
        self.configfile = os.path.join(self.location, OSGRSV.DEFAULT_CONFIG_FILE)
        self.user = user
        
        #submitter
        self.submitter = None
        
        # configuration parameters
        self.config = OSGRSV.DEFAULT_CONFIG
        self._loadconfig(config)        
        
        self.register_svc = os.path.join(self.vdtlocation, "vdt/sbin/vdt-register-service") # "$VDT_LOCATION/vdt/sbin/vdt-register-service";
        self.initfile = os.path.join(os.path.join(self.vdtlocation, "post-install"), self.name) # "$VDT_LOCATION/post-install/$OSG_RSV_NAME";
        self.rsv_vdtapp = os.path.join(self.vdtlocation, "vdt-app-data/osg-rsv")
        
        # The Gratia ProbeConfig file should be a symlink.  We need the real location,
        # or else when we safe_write it, we'll overwrite the symlink.
        self.gratia_probeconf = os.path.realpath(os.path.join(self.vdtlocation, "gratia/probe/metric/ProbeConfig")) #"$VDT_LOCATION/gratia/probe/metric/ProbeConfig";

        # RSV no longer allow for Condor-Devel pre-installs, so just look for condor-cron and that's it
        # why not search in the environment?
        self.condorcron = os.path.join(self.vdtlocation, "condor-cron")  # default condor-cron installation "$VDT_LOCATION/condor-cron";
        if not os.path.exists(self.condorcron):
            log.error("Cannot find Condor-Cron at $VDT_LOCATION/condor-cron")
            # raise some error/exception

        ###TRAnslate
        # Always make sure we have the directories setup
        self.setup_dirs()

        # Preserve old (Probe?) config if necessary 
        if os.getenv('OLD_VDT_LOCATION'):
            self.preserve_old_config() 

    # Functions to save and recover configuration
    def _saveconfig(self):
        # TODO: replace with something more robust (pickle, .ini)
        fp = open(self.configfile, 'w')
        fp.write(str(self.config))
        fp.close()
        
    def _loadconfig(self, override=None):
        try:
            lines = open(self.configfile).readlines()
            tmp = eval('\n'.join(lies))
        except IOError:
            tmp = {}
        for k, v in tmp.items():
            self.config[k] = v
        if override:
            for k, v in override.items():
                self.config[k] = v
    # end
    
    def cleanHTML(self):
        """Clean HTML output
        - remove HTML subpages
        - remove HTML main page
        - kill HTML consumer to recreate updated pages
        """
        for i in [os.path.join(self.getHtmlOutputDir(), j) for j in os.listdir(self.getHtmlOutputDir())]:
            if os.path.isdir(i):
                try:
                    tmp_fname = os.path.join(i, "index.html")
                    os.remove(tmp_fname)
                    log.info("Removed html file "+tmp_fname)
                except OSError:
                    if os.path.isfile(tmp_fname):
                        log.warning("Unable to remove the file: "+tmp_fname)
        try:
            tmp_fname = os.path.join(self.getHtmlOutputDir(), "index.html")
            os.remove(tmp_fname)
            log.info("Removed html file "+tmp_fname)
        except OSError:
            if os.path.isfile(tmp_fname):
                log.warning("Unable to remove the file: "+tmp_fname)
        #Kill HTML consumer to refresh HTML files (Condor will restart it)
        cmd = "pkill -f html-consumer"
        if self.user:
            cmd = 'su -c "%s" %s' % (cmd, self.user)
        raw_ec = os.system(cmd)
        #if os.WIFEXITED(raw_ec):
        exit_code = os.WEXITSTATUS(raw_ec) 
        log.info("HTML consumer killed: %s (%s). Being restarted."%(exit_code, raw_ec))
        # Should check for new pid? "pgrep -f html-consumer"
        return
    
    def getSubmitter(self):
        if not self.submitter:
            import condorsubmitter as subm
            self.submitter = subm.getSubmitter(rsv=self, user=self.user)
        return self.submitter
    
    def configure(self):
        self._saveconfig()        

    # Function returning Paths. 
    # For the one that can be probe specific, should consider also consumers (and become getProbeXXX)? 
    def getProxyFile(self):
        if self.config['rsv_use_service_cert']:
            return self.config['rsv_proxy_file']
        tmp =  self.config['proxy']
        if tmp.endswith('<uid>'):
            #ALT: if the current user is not the expected user
            # import pwd, u1=pwd.getpwnam(self.config['username']), rsvid=u1.pw_uid
            rsvid = os.getuid()
            return "%s%s" % (tmp[:-5], rsvid)
        return tmp

    def getLocation(self):
        return self.location

    def getVdtLocation(self):
        return self.vdtlocation
    
    def getSpecDir(self):
        return os.path.join(self.location, "specs")
    
    def getBinDir(self):
        return os.path.join(self.location, "bin/probes")
    getPerlLibDir = getBinDir
    
    def getLogDir(self):
        return os.path.join(self.location, "logs/probes")
    
    def getSubmitDir(self):
        return os.path.join(self.location, "submissions/probes")
    
    def getHtmlOutputDir(self):
        return os.path.join(self.location, "output/html")

    def setup_dirs(self):
        """Create the appropriate directories, and make sure they have the right permissions
        """
        # TODO: implement
        return    
    
    def preserve_old_config(self):
        "Preserve old config"
        # TODO: implement
        return

    def getVersion(self, verbose=False):
        "Print the RSV version"
        #placeholder
        #TODO: provide better method
        # vdt-version provides several lines
        # 2 are about RSV and the probes: OSG Resource and Service Validation (RSV) 
        ec, out = commands.getstatusoutput("vdt-version")
        # control ec?
        if out:
            lines = [i for i in out.split('\n') 
                     if i.startswith('OSG Resource and Service Validation (RSV)')>=0]
            if verbose:
                return '\n'.join(lines)
            start = len('OSG Resource and Service Validation (RSV)')
            version = lines[0][start:57].strip()
            return version
        return ""

    def describe(self, verbose=False, prefix=''):
        outstr = "%sRSV installation\n%s version %s\n" % (prefix, prefix, self.getVersion())
        outstr += "%s Install dir: %s\n" % (prefix, self.getLocation())
        outstr += "%s Directories: PerlLib %s, Log %s, Submit %s\n" % (prefix, self.getPerlLibDir(), self.getLogDir(), self.getSubmitDir())
        if self.config:
            tmp = "Options: "
            for k, v in self.config.items():
                tmp += "%s (%s), " % (v, k)
            outstr += "%s %s\n" % (prefix, tmp[:-2],)
        if verbose:
            outstr += "%s Probes:\n" % (prefix,)
            try:
                #dlist = os.listdir(self.getPerlLibDir())
                dlist = [i for i in os.listdir(self.getPerlLibDir()) if i.endswith('probe')]
                outstr += "%s\n" % ('\n'.join(dlist),)
            except OSError:
                # PerlLibDir not existent/accessible
                pass
        #outstr += "" % ()
        return outstr
        
    def getInstalledProbes(self, uridict=None, options_=None):
        """Lists all the probes installed in the bin directory
        Unless uridict is passed, no attention to URI is given 
        Perturn value contains one probe per installed probe binary
        """
        #TORM: on top: from Probe import loadProbeFromFile
        probes = []
        for probefile in os.listdir(self.getBinDir()):
            if not probefile.endswith("-probe"):
                # directory may contain other files, probe files end in "-probe"
                continue
            #TODO: handle multiple metrics
            #probe = loadProbeFromFile(probefile, self, uridict=uridict)
            #if probe:
            #    probes.append(probe)
            #TODO: handle multiple metrics
            tmp_probes = loadAllProbesFromFile(probefile, self, uridict=uridict, options_=options_)
            probes += tmp_probes 
            #if probe: #if none and not empty list
            #    probes.append(probe)
        return probes

    def getConfiguredProbes(self, hostid=None, options_=None):
        """Gets all the configured probes
        Scan for all the installed metric files (configuration files, one per host, only the required host)
        Return one probe for each line in a metric file (lines referring the same executable are condensed in a single one)
        """
        fnamelist = []
        metricsarchive = {}
        onehost = False
        strend = -len("_metrics.conf")
        if hostid:
            fnamelist = [os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)]
            onehost = True
        else:
            names = os.listdir(self.metrics_loc)
            # this may require python 2.4:
            fnamelist = [os.path.join(self.metrics_loc, name) for name in names if name.endswith("_metrics.conf") and not name=="sample_metrics.conf"]
        for fname in fnamelist:
            if not os.path.isfile(fname):
                log.warning("Expected file missing: " + fname)
                continue
            if not onehost:
                hostid = os.path.basename(fname)[:strend]
            metricsarchive[hostid] = self._read_metrics_file(fname)
        probelist = []
        probearchive = {}
        # not used: probemetrics = {}
        for h in metricsarchive.keys():
            for k in metricsarchive[h].keys():
                fname, mname = k.split('@', 1)
                #TODO: improve in the future, now suppose that URI and host are the same
                uri = h
                selprobe = None
                try:
                    for probe in probearchive[fname]:
                        if mname==probe.metricName:
                            selprobe = probe
                        # Warning printed when probelist was defined
                        #else:
                        #    log.warning("LCG standard violation. Probe producing multiple metrics: %s" % (fname,))
                except KeyError:
                    probelist = loadAllProbesFromFile(fname, self, options_=options_)
                    if not probelist:
                        log.warning("Error in loading probes %s, %s" % (h, k))
                        continue
                    if len(probelist)==1:
                        selprobe = probelist[0]
                    else:                            
                        log.warning("LCG standard violation. Probe producing multiple metrics: %s" % (fname,))
                        for probe in probelist:
                            if mname==probe.metricName:
                                selprobe = probe
                                break
                    probearchive[fname] = probelist
                    # not used: probemetrics[fname] = []
                # add values to selprobe    
                if not selprobe:
                    log.warning("No probe with URI %s and key %s" % (uri,k))
                    continue
                val = metricsarchive[h][k]
                # not used: probemetrics[fname].append(mname)
                selprobe.addURI(uri)
                selprobe.setCronValues([val['CronMinute'], val['CronHour'], val['CronDayOfMonth'], 
                                        val['CronMonth'], val['CronDayOfWeek']])
                # probe enabled = val['enable'] on/off
                """        try:
                    probearchive[fname].addURI(uri)
                    if not mname==probemetrics[fname]:
                        log.warning("One probe producing multiple metrics. LCG standard violation")
                except KeyError:
                    probe = loadProbeFromFile(fname, self, uri)
                    if not probe:
                        log.warning("Error in loading probe %s, %s" % (h, k))
                        continue
                    val = metricsarchive[h][k]
                    probemetrics[fname] = mname
                    probe.setCronValues([val['CronMinute'], val['CronHour'], val['CronDayOfMonth'], 
                                         val['CronMonth'], val['CronDayOfWeek']])
                    # probe enabled = val['enable'] on/off
                    probearchive[fname] = probe
        """
        #
        retlist = [i for i_list in probearchive.values() for i in i_list]
        return retlist

    def isValidProbeID(self, id):
        """Checks ID syntax and returns True/Flse
        hostName__fileName@metricsName
        """
        #TODO: may want also check if the probe is installed/configured
        try:
            ind1 = id.find("__")
        except:
            return False
        if ind1>0:
            ind2 = id.find('@')
            if ind2>ind1: # ind2>(ind1+3)
                return True
        return False
    
    def getProbeByID(self, id):
        # ID like host__fname@URI
        if not id:
            log.error("Invalid probe ID, unable to retrieve probe.")
            return None
        hostid, pkey = id.split('__', 1)
        pfname, ptype = pkey.split('@', 1)
        mfname = os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)
        if not os.path.isfile(mfname):
            log.error("Probe's metric file missing: " + mfname)
            return None
        probemetrics = self._read_metrics_file(pfname)
        #TODO: handle multiple metrics
        probe = loadProbeFromFile(pfname, self, hostid)
        if not probe:
            log.error("Error in loading probe %s, %s" % (h, k))
            return None
        try:
            val = probemetrics[pkey]
            probe.setCronValues([val['CronMinute'], val['CronHour'], val['CronDayOfMonth'], 
                                 val['CronMonth'], val['CronDayOfWeek']])
        except KeyError:
            log.warning("No metrics values for the Probe")
        return probe
    
    def metricsFileFix(self, hostid):
        fname = os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)
        if not os.path.isfile(fname):
            try:
                fp = open(fname,'w')
                fp.write("# Test configuration file for host %s" % (hostid,))
                fp.close()
                log.info("Created metrics file: "+fname)
            except IOError:
                log.error("Unable to create metrics file: "+fname)
        file_ok = self.metricsFileCheck(hostid)
        if not file_ok:
            #TODO fix the file
            pass
        return file_ok

                
    def metricsFileCheck(self, hostid=None):
        """Check metrics file consistency:
        - lines starting with 'o' are non comment lines
        - all non comment lines should have 7 elements: "%-4s %-70s %-4s %-4s %-4s %-4s %-4s\n"
        - metricIDs (second entry) should be unique
        hostid: to check a specific metrics file, if not provided all metrics files are checked
        retuns False if any of the inspected files are inconsistent. Anyway it inspects all requested files. 
        Check the log file for results
        """
        fnamelist = []
        file_ok = True
        if hostid:
            fnamelist = [os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)]
        else:
            names = os.listdir(self.metrics_loc)
            # this may require python 2.4:
            fnamelist = [os.path.join(self.metrics_loc, name) for name in names if name.endswith("_metrics.conf")]
        for fname in fnamelist:
            if not os.path.isfile(fname):
                file_ok = False
                log.warning("Expected file missing: " + fname)
                continue
            lines = open(fname).readlines()
            linedict = {}
            for line in lines:
                if line and line[0] == 'o':
                    info = line.split()
                    if not len(info)==7:
                        file_ok = False
                        log.warning("Invalid non comment line in metrics file %s:\n<%s>" % (fname, lines[i]))
                        continue
                    key = info[1].strip()
                    if key in linedict.keys(): 
                        linedict[key].append(line)
                        file_ok = False
                        log.warning("Duplicate metric %s in metrics file %s:\n%s" % (key, fname, linedict[key]))
                    else:
                        linedict[key] = [line]
        return file_ok

    def metricsFileRetrieve(self, hostid, metricid, default=None):
        """retrieve a metric from file. Optional default if metric is not found
        hostid (host from the URI)
        metricid (probe.getKey, basename@metricName)
        """
        # assuming thet none of hostid, metricid are null. check?
        fname = os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)
        if not os.path.isfile(fname):
            return default
        lines = open(fname).readlines()
        for line in lines:
            if line and line[0] == 'o':                    
                if line.find(metricid) >= 0:
                    info = line.split()
                    if not len(info)==7:
                        log.warning("Invalid matching line in metrics file %s:\n<%s>. Skipping." % (fname, lines[i]))                        
                        continue
                    retval = { 'enable': True }
                    if info[0] == 'off':
                        retval = { 'enable': False }
                    retval['CronMinute'] = info[2]
                    retval['CronHour'] = info[3]
                    retval['CronDayOfMonth'] = info[4]
                    retval['CronMonth'] = info[5]
                    retval['CronDayOfWeek'] = info[6]
                    return retval
        return default

    def metricsFileMakeEntry(enabled, minute, hour, domonth, month, doweek):
        "enabled(boolean), 5 cron values" 
        retv = {'enable': enabled,
                'CronMinute': minute,
                'CronHour': hour,
                'CronDayOfMonth': domonth,
                'CronMonth': month,
                'CronDayOfWeek': doweek,
            }
        return retv
    metricsFileMakeEntry = staticmethod(metricsFileMakeEntry)

    def metricsFileUpdate(self, hostid, metricid, entry_par, default=None):
        """Change the config file. Returns True if the metrics file changed
        - hostid is fqdn
        - metricid is a key fname@metricName
        - entry_par list of parameters enabled(boolean), 5 cron values (minute, hour, domonth, month, doweek)
        """
        # assuming that none of hostid, metricid, entry_par are null. check?
        if type(entry_par)==type({}):
            entry = entry_par
        else:
            entry = OSGRSV.metricsFileMakeEntry(*entry_par)
        fname = os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)
        if not os.path.isfile(fname):
            return False
        lines = open(fname).readlines()
        if not default:
            default = self.DEFAULT_CONFIG_ENTRY
        changed = False
        matching_index = -1
        oldentry = {}
        for i in range(len(lines)): #line in lines:
            if lines[i] and lines[i][0] == 'o':                    
                if lines[i].find(metricid) >= 0:
                    info = lines[i].split()
                    if not len(info)==7:
                        log.warning("Invalid matching line in metrics file %s:\n<%s>. Skipping." % (fname, lines[i]))                        
                        continue
                    # line matches and has 7 elements
                    oldentry = { 'enable': True }
                    if info[0] == 'off':
                        oldentry = { 'enable': False }
                    oldentry['CronMinute'] = info[2]
                    oldentry['CronHour'] = info[3]
                    oldentry['CronDayOfMonth'] = info[4]
                    oldentry['CronMonth'] = info[5]
                    oldentry['CronDayOfWeek'] = info[6]
                    matching_index = i
                    break
        # end for
        # update entry dictionary
        if not oldentry:
            oldentry = default
        # to allow both missing values and none values 
        for j in entry.keys():
            if entry[j]:  # this will skip None but also a boolean set to False
                if entry[j] != oldentry[j]:
                    changed = True
                    oldentry[j] = entry[j]
        try:
            if entry['enable']==False and oldentry['enable']==True:
                oldentry['enable'] = False
                changed = True
        except KeyError:
            pass
        if oldentry['enable']:
            templ = "on   %-70s %-4s %-4s %-4s %-4s %-4s\n" 
        else:
            templ = "off  %-70s %-4s %-4s %-4s %-4s %-4s\n" 
        retv = templ % ( metricid, 
                         oldentry['CronMinute'], 
                         oldentry['CronHour'], 
                         oldentry['CronDayOfMonth'], 
                         oldentry['CronMonth'], 
                         oldentry['CronDayOfWeek'],
                     )
        if matching_index:
            # only if changed=True?
            lines[matching_index] = retv
        else:
            lines.append(retv)
            changed = True
        # write output file
        if changed:                        
            open(fname, 'w').write(''.join(lines))
            # Safe write is in Submitter
            # _safe_write(fname, ''.join(lines))
            log.info("Metrics file updated: %s" % (fname,))
        return changed
    
    def _metricsFileRead(self, hostid):
        fname = os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)
        return _read_metrics_file(fname)
    
    def _read_metrics_file(fname):
        # Parse metrics file
        # Columns - Enable | Probe@Metric | Cron Minute | Cron Hour | Cron Day of Month | Month | Day of Week
        metrics = {}
        log.debug("Re-using metrics config file for "+fname+"\n"+
                 " Existing settings like on/off and metric intervals will be used.\n"+
                 " Any new metrics found in probe set will be used with their default settings.")
        #if os.path.isfile("$METRICS_DIR/${host}_metrics.conf") ;
        if os.path.isfile(fname):
            lines = open(fname).readlines()
            for line in lines:
                if line.startswith('on') or line.startswith('off'):
                    info = line.split()
                    if not len(info)==7:
                        log.warning("Invalid line in metrics file (%s).  Skipping." % (line,))
                        continue
                    metrics[info[1]] = { 'enable': 'on' }
                    if info[0] == 'off':
                        metrics[info[1]] = { 'enable': 'off' }
                    metrics[info[1]]['CronMinute'] = info[2]
                    metrics[info[1]]['CronHour'] = info[3]
                    metrics[info[1]]['CronDayOfMonth'] = info[4]
                    metrics[info[1]]['CronMonth'] = info[5]
                    metrics[info[1]]['CronDayOfWeek'] = info[6]
                    #metrics[info[1]][''] = info[]
        return metrics
    _read_metrics_file = staticmethod(_read_metrics_file)

    def _metricsFileWrite(self, hostid, metrics):
        fname = os.path.join(self.metrics_loc, "%s_metrics.conf" % hostid)
        return _write_metrics_file(fname, metrics)
    
    def _write_metrics_file(fname, metrics):
        # Header for metrics configuration file
        outstr = "Enable | Probe\@Metric | Cron Minute | Cron Hour | Cron Day of Month | Cron Month | Cron Day of Week\n\n";

        # Print out the metrics.  It doesn't matter if they are sorted, but it 
        # might prevent the file from being written if it doesn't change?, since
        # python returns keys in semi-random order (hash)

        for metric in metrics.keys().sort():
            outstr += "%-4s %-70s %-4s %-4s %-4s %-4s %-4s\n" % ( metrics[metric]['enable'], 
                                                                  metric, 
                                                                  metrics[metric]['CronMinute'], 
                                                                  metrics[metric]['CronHour'], 
                                                                  metrics[metric]['CronDayOfMonth'], 
                                                                  metrics[metric]['CronMonth'], 
                                                                  metrics[metric]['CronDayOfWeek']
                                                              )                              
        # Don't register the HOST_metrics.conf files, we don't want to uninstall them
        open(fname, 'w').write(outstr)
        # TODO: Safe write i in Submitter
        #  _safe_write(fname, outstr);
    _write_metrics_file = staticmethod(_write_metrics_file)

    def start(self):
        """
        start() {
   echo -n "Starting OSG-RSV: "

   # Make sure the jobs are not already in the queue
   if [ `$CONDOR_EXE_QUEUE -constraint 'OSGRSV == "probes"' | grep probe_wrapper | wc -l` -gt 0 ]; then
      echo "OSG-RSV jobs are already in the condor queue"
      return 0
   fi

   # Set the permissions on appropriate directories
   if [ `id -u` == 0 ]; then
      chown -R $RUN_AS_USER !!OSG_RSV_LOCATION!!/logs/ > /dev/null 2>&1
      chown -R $RUN_AS_USER !!OSG_RSV_LOCATION!!/output/ > /dev/null 2>&1
   fi
 
   # Print an error message if there are no probes to submit
   if [ `ls $OSG_RSV_PROBES/*.sub 2>/dev/null | wc -l` -eq 0 ]; then
      echo "ERROR: No probes configured!"
      exit 1
   fi

   # Submit probes
   cd $VDT_LOCATION
   for file in `find $OSG_RSV_PROBES -name "*.sub"`; do
      if [ `id -u` == 0 ]; then
         su -c "$CONDOR_EXE_SUBMIT $file" $RUN_AS_USER > /dev/null 2>&1
      else
         $CONDOR_EXE_SUBMIT $file > /dev/null 2>&1
      fi
      if [ $? != 0 ]; then
         echo
         echo "ERROR: Failed to submit '$file' into Condor"
         exit 1
      fi
   done

   # Submit consumers
   for file in `find $OSG_RSV_CONSUMERS -name "*.sub"`; do
      if [ `id -u` == 0 ]; then
         su -c "$CONDOR_EXE_SUBMIT $file" $RUN_AS_USER > /dev/null 2>&1
      else
         $CONDOR_EXE_SUBMIT $file > /dev/null 2>&1
      fi
      if [ $? != 0 ]; then
         echo
         echo "ERROR: Failed to submit '$file' into Condor"
         exit 1
      fi
   done
   echo "Done"
   return 0
}
"""
        # Make sure the jobs are not already in the queue
        if self.submitter.areProbesRunning():
            log.error("OSG-RSV jobs are already in the condor queue. Stop OSG-RSV first. Start aborted.")
            return
        #TODO: implement start
        return

    def stop(self):
        """stop() {
   echo -n "Stopping OSG-RSV: "
   ##
   ## The jobs that we submitted all have a special attribute that makes it
   ## easier for us to track and remove
   ##
   $CONDOR_EXE_REMOVE -constraint 'OSGRSV == "probes"' > /dev/null 2>&1
   if [ $? != 0 ]; then
      RETVAL=$?
      echo
      echo "ERROR: Failed to remove probe jobs from Condor"
   fi
   $CONDOR_EXE_REMOVE -constraint 'OSGRSV == "consumers"' > /dev/null 2>&1
   if [ $? != 0 ]; then
      RETVAL=$?
      echo
      echo "ERROR: Failed to remove consumer jobs from Condor"
   fi
   if [ $RETVAL == 0 ]; then
      echo "Done"
   fi
   return $RETVAL
}
"""
        #TODO: implement stop
        return
    
#for debugging
#commands to allow autocompletion
#import Probe
#mprobe = Probe.ProbeLocal()
#mrsv = OSGRSV()

def getStatus(probe, rsv, verbose=False):
    rsv = OSGRSV()
    mprobe.get
    rsv.metricsFileRetrieve()

def main():
    import sys
    import Probe
    probe = Probe.ProbeLocal('cacert-expiry')
    if len(sys.argv)>1:
        rsv = OSGRSV(sys.argv[1])
    else:
        rsv = OSGRSV('test/vdtlocation')
    # turn on probe
    print "RSV server"
    print rsv.describe()
    
    probe.rsv = rsv    
    print "Probe"
    print probe.describe()
    
    import condorsubmitter
    submitter = condorsubmitter.CondorSubmitter(rsv)
    
    submitter.submit(probe)
    submitter.list(probe)
    
if __name__ == '__main__':
    main()
