package CertLib;
use strict;
use LWP::UserAgent;

# $Id: CertLib.pm,v 1.3 2007/03/19 23:57:43 olson Exp $
# $Source: /home/olson/MyCVS/cert-scripts/lib/CertLib.pm,v $
# $Date: 2007/03/19 23:57:43 $
# $Author: olson $

my $pkgversion = "2-2";


################################################################################
# stuff for the OSG cert-scripts package in VDT
################################################################################

sub new {
    my $class = shift;
    my $self = {};
    $self->{RAS} = load_ras("http://www.ppdg.net/RA/communities/doegrids-ras.txt");
#    print $self->{RAS};
    
    $self->{OSGVOS} = load_vos("http://www.grid.iu.edu/osg-includes/vos.php");
    

    my %doegridsca = (
		      enrollment => 'https://pki1.doegrids.org/enrollment',
		      cpcps => 'http://www.doegrids.org/Docs/CP-CPS.pdf',
		      retrieve => 
    'https://pki1.doegrids.org/displayBySerial?op=displayBySerial&serialNumber=');
    my %testca = (
		  enrollment => 'https://amber.es.net/enrollment',
		  cpcps => 'none',
		  retrieve =>
    'https://amber.es.net/displayBySerial?op=displayBySerial&serialNumber=');
    my %cas = ( doegrids => \%doegridsca,
		    testca => \%testca);
    $self->{CA} = \%cas;
    bless ($self, $class);
    return $self;
}

sub osgvos {
    my $self = shift;
    return %{$self->{OSGVOS}};
}

sub ras {
    my $self = shift;
    return %{$self->{RAS}};
}

sub cas {
    my $self = shift;
    return %{$self->{CA}};
}

sub load_ras($) {
    my $rasurl = shift;
    my %ras;
    my %defras = (
	     anl => 'ANL: Argonne National Lab',
	     esg => 'ESG: Earth System Grid',
	     esnet => 'ESnet: DOE Science network',
	     fnal => 'FNAL: Fermilab certificates',
	     fusiongrid => 'FusionGRID: National Fusion Grid Project',
	     lbnl => 'LBNL: Berkeley Lab',
	     lcg => 'LCG: LHC Computing Grid',
	     nersc => 'NERSC: computer center, see www.nersc.gov',
	     ornl => 'ORNL: Oak Ridge National Lab',
	     osg => 'OSG: Open Science Grid (choose this if nothing else applies)',
	     pnnl => 'PNNL: Pacific Northwest National Lab'
		 );
    my $ua = LWP::UserAgent->new;
    # Use a proxy if user has proxy set in their environment:
    $ua->env_proxy;
    # BUG:  http://rt.cpan.org/Public/Bug/Display.html?id=1894
    #  - Cannot use LWP proxy for https requests, Crypt::SSLeay
    #    will do its own proxy negotiation correctly if the
    #    https_proxy variable is set in the user's environment.
    $ua->proxy(https => undef);

    $ua->agent("CertLib/" . $pkgversion . " ");
    my $req = HTTP::Request->new(GET => $rasurl);
    my $res = $ua->request($req);
    if (index($res->content,"rror") == -1) {
	my @aras = split('\n',$res->content);
	my ($label,$descr);
	while (($label,$descr) = split(",",pop(@aras))) {
	    $ras{$label} = $descr;
#	    print "label $label, descr $descr\n";
	}
	
    } else {
	%ras = %defras;
    }
    return \%ras;
}

#################### get_osgvolist #####################
sub load_vos($) {
    my $url = shift;
    my %vos;
    my %defvos = (
		  cdf => 'CDF: Collider Detector at Fermilab',
		  cms => 'CMS: Compact Muon Solenoid',
		  compbiogrid => 'CompBioGrid: Computational Cell Biology',
		  des => 'DES: Dark Energy Survey',
		  dosar => 'DOSAR: Distributed Organization for Scientific and Academic Research',
		  dzero => 'DZero: D0 Experiment',
		  engage => 'Engage: OSG Engagement Activity',
		  fermilab => 'Fermilab: The Fermilab VO',
		  fmri => 'fMRI: Functional Neuroimaging Community, Dartmouth Brain Imaging Center, and Dartmouth Community',
		  gadu => 'GADU: Genome Analysis and Database Update',
		  geant4 => 'geant4: Simulation toolkit for high energy physics experiments and biomedical applications',
		  glow => 'GLOW: Grid Laboratory of Wisconsin',
		  gpn => 'GPN: Great Plains Network',
		  grase => 'GRASE: Grid Resources for Advanced Science and Engineering',
		  gridex => 'GridEx: Grid Exerciser',
		  grow => 'GROW: Grid Research and educatiOn group @ IoWa',
		  gugrid => 'GUGrid: Georgetown University Grid',
		  i2u2 => 'i2u2: Interactions in Understanding The Universe',
		  ivdgl => 'iVDGL: International Virtual Data Grid Laboratory',
		  ligo => 'LIGO: Laser Interferometer Gravitational Wave Observatory',
		  mariachi => 'MARIACHI: Mixed Apparatus for Radar Investigation of Cosmic-rays of High Ionization',
		  mis => 'MIS: Monitoring Information System',
		  nanohub => 'nanoHUB: Online simulations and more',
		  nwicg => 'NWCIG: Northwest Indiana Computational Grid',
		  osg => 'OSG: Open Science Grid VO for small groups and individuals',
		  osgedu => 'OSGEDU: OSG VO for educational grid workshops',
		  sdss => 'SDSS: Sloan Digital Sky Survey',
		  star => 'STAR: The STAR Experiment',
		  usatlas => 'USATLAS: ATLAS in US (A Toroidal Lhc ApparatuS)'
		 );
    my %inst_vos = (
		    bnl => 'BNL: Brookhaven lab researchers not in an OSG registered VO',
		    jlab => 'JLab: Jefferson Lab researchers',
		    slac => 'SLAC: Stanford Linear Accelerator Center researchers',
		   );
    my $ua = LWP::UserAgent->new;
    # Use a proxy if user has proxy set in their environment:
    $ua->env_proxy;
    # BUG:  http://rt.cpan.org/Public/Bug/Display.html?id=1894
    #  - Cannot use LWP proxy for https requests, Crypt::SSLeay
    #    will do its own proxy negotiation correctly if the
    #    https_proxy variable is set in the user's environment.
    $ua->proxy(https => undef);

    $ua->agent("RequestScript/" . $pkgversion . " ");
    my $req = HTTP::Request->new(GET => $url);
    my $res = $ua->request($req);
#    print $res->content;
    my @osgvos = split("<br>",$res->content);
    my $i;
    my ($vo,$desc);
    for ($i=0; $i< @osgvos; $i++) {
#	print $osgvos[$i]."\n";
	$vo = $desc = "";
	($vo, $desc) = split('\|\|', $osgvos[$i]);
	$vo =~ s/^\s*//; # clean left whitespace
	$vo =~ s/\s*$//; # clean right whitespace
	$desc =~ s/^\s*//; # clean left whitespace
	$desc =~ s/\s*$//; # clean right whitespace	
#	printf("vo: %s, desc: %s\n",$vo,$desc);
	$vos{$vo} = $desc;
    }
    if (! $vos{'osg'}) {
	%vos = %defvos;
    }
    while (($vo,$desc) = each %inst_vos) {
	$vos{$vo} = $desc;
    }
    return \%vos;
}


1;

#################### CVS Log #################################
#
# $Log: CertLib.pm,v $
# Revision 1.3  2007/03/19 23:57:43  olson
# V2-2  added http_proxy support
#
# Revision 1.2  2006/11/17 22:38:54  olson
# update list of VOs, add RCS keywords
#
