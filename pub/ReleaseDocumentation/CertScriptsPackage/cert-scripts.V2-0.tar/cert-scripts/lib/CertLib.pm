package CertLib;
use strict;
use LWP::UserAgent;

my $pkgversion = "2.0";


################################################################################
# stuff for the OSG cert-scripts package in VDT
################################################################################

sub new {
    my $class = shift;
    my $self = {};
    $self->{RAS} = load_ras("http://www.ppdg.net/RA/communities/doegrids-ras.txt");
#    print $self->{RAS};
    
    $self->{OSGVOS} = load_vos("http://www.grid.iu.edu/osg-includes/vos.php");
    

    my %doegridsca = (
		      enrollment => 'https://pki1.doegrids.org/enrollment',
		      cpcps => 'http://www.doegrids.org/Docs/CP-CPS.pdf',
		      retrieve => 
    'https://pki1.doegrids.org/displayBySerial?op=displayBySerial&serialNumber=');
    my %testca = (
		  enrollment => 'https://amber.es.net/enrollment',
		  cpcps => 'none',
		  retrieve =>
    'https://amber.es.net/displayBySerial?op=displayBySerial&serialNumber=');
    my %cas = ( doegrids => \%doegridsca,
		    testca => \%testca);
    $self->{CA} = \%cas;
    bless ($self, $class);
    return $self;
}

sub osgvos {
    my $self = shift;
    return %{$self->{OSGVOS}};
}

sub ras {
    my $self = shift;
    return %{$self->{RAS}};
}

sub cas {
    my $self = shift;
    return %{$self->{CA}};
}

sub load_ras($) {
    my $rasurl = shift;
    my %ras;
    my %defras = (
	     anl => 'ANL: Argonne National Lab',
	     esg => 'ESG: Earth System Grid',
	     esnet => 'ESnet: DOE Science network',
	     fnal => 'FNAL: Fermilab certificates',
	     fusiongrid => 'FusionGRID: National Fusion Grid Project',
	     lbnl => 'LBNL: Berkeley Lab',
	     lcg => 'LCG: LHC Computing Grid',
	     nersc => 'NERSC: computer center, see www.nersc.gov',
	     ornl => 'ORNL: Oak Ridge National Lab',
	     osg => 'OSG: Open Science Grid (choose this if nothing else applies)',
	     pnnl => 'PNNL: Pacific Northwest National Lab'
		 );
    my $ua = LWP::UserAgent->new;
    $ua->agent("CertLib/" . $pkgversion . " ");
    my $req = HTTP::Request->new(GET => $rasurl);
    my $res = $ua->request($req);
    if (index($res->content,"rror") == -1) {
	my @aras = split('\n',$res->content);
	my ($label,$descr);
	while (($label,$descr) = split(",",pop(@aras))) {
	    $ras{$label} = $descr;
#	    print "label $label, descr $descr\n";
	}
	
    } else {
	%ras = %defras;
    }
    return \%ras;
}

#################### get_osgvolist #####################
sub load_vos($) {
    my $url = shift;
    my %vos;
    my %defvos = (
		  cdf => 'CDF: Collider Detector at Fermilab',
		  cms => 'CMS: Compact Muon Solenoid',
		  des => 'DES: Dark Energy Survey',
		  dosar => 'DOSAR: Distributed Organization for Scientific and Academic Research',
		  dzero => 'DZero: D0 Experiment',
		  fmri => 'fMRI: Functional Neuroimaging Community, Dartmouth Brain Imaging Center, and Dartmouth Community',
		  gadu => 'GADU: Genome Analysis and Database Update',
		  geant4 => 'geant4: Simulation toolkit for high energy physics experiments and biomedical applications',
		  glow => 'GLOW: Grid Laboratory of Wisconsin',
		  grase => 'GRASE: Grid Resources for Advanced Science and Engineering',
		  gridchem => 'Computational Chemistry Grid, www.gridchem.org',
		  gridex => 'GridEx: Grid Exerciser',
		  grow => 'GROW: Grid Research and educatiOn group @ IoWa',
		  gugrid => 'GUGrid: Georgetown University Grid',
		  i2u2 => 'i2u2: Interactions in Understanding The Universe',
		  ivdgl => 'iVDGL: International Virtual Data Grid Laboratory',
		  ligo => 'LIGO: Laser Interferometer Gravitational Wave Observatory',
		  mariachi => 'MARIACHI: Mixed Apparatus for Radar Investigation of Cosmic-rays of High Ionization',
		  mis => 'MIS: Monitoring Information System',
		  nanohub => 'nanoHUB: Online simulations and more',
		  nwicg => 'NWCIG: Northwest Indiana Computational Grid',
		  osg => 'OSG: Open Science Grid VO for small groups and individuals',
		  osgedu => 'OSGEDU: OSG VO for educational grid workshops',
		  sdss => 'SDSS: Sloan Digital Sky Survey',
		  star => 'STAR: The STAR Experiment',
		  usatlas => 'USATLAS: ATLAS in US (A Toroidal Lhc ApparatuS)'
		 );
    my %inst_vos = (
		    bnl => 'BNL: Brookhaven lab researchers not in an OSG registered VO',
		    jlab => 'JLab: Jefferson Lab researchers',
		    slac => 'SLAC: Stanford Linear Accelerator Center researchers',
		   );
    my $ua = LWP::UserAgent->new;
    $ua->agent("RequestScript/" . $pkgversion . " ");
    my $req = HTTP::Request->new(GET => $url);
    my $res = $ua->request($req);
#    print $res->content;
    my @osgvos = split("<br>",$res->content);
    my $i;
    my ($vo,$desc);
    for ($i=0; $i< @osgvos; $i++) {
#	print $osgvos[$i]."\n";
	$vo = $desc = "";
	($vo, $desc) = split('\|\|', $osgvos[$i]);
	$vo =~ s/^\s*//; # clean left whitespace
	$vo =~ s/\s*$//; # clean right whitespace
	$desc =~ s/^\s*//; # clean left whitespace
	$desc =~ s/\s*$//; # clean right whitespace	
#	printf("vo: %s, desc: %s\n",$vo,$desc);
	$vos{$vo} = $desc;
    }
    if (! $vos{'osg'}) {
	%vos = %defvos;
    }
    while (($vo,$desc) = each %inst_vos) {
	$vos{$vo} = $desc;
    }
    return \%vos;
}


1;
