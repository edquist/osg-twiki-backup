#!/bin/bash

# this will flatten a file, with exercise completions as specified

# $1  file (with path) ending in .EX

INFILE=$1
BASENAME=`echo $1 | sed s/.OS//`

echo generating $BASENAME

while [ "X$2" != "X" ] ; do
    DEFS="$DEFS -DOS$2"
    shift
done


m4 $DEFS --include=m4/ < $INFILE > $BASENAME

