









package org.globus.tutorial.stickynote;

import java.rmi.RemoteException;

import org.globus.wsrf.ResourceContext;
import org.globus.wsrf.ResourceKey;
import org.globus.wsrf.utils.AddressingUtils;

import org.apache.axis.message.addressing.EndpointReferenceType;



/** This is the code for the StickyNote webservice.
*/

public class StickyNoteService
{

    /** Implementation of the 'write' operation, to wrtie text onto the
        the note. */
    public WriteResponse write(String text) throws RemoteException
    {
        // get appropriate resource

        StickyNote resource = (StickyNote)
            ResourceContext.getResourceContext().getResource();

        // set the text on it
        resource.setMessage(text);

        return new WriteResponse();
    }


// EXERCISE 2 (completed) : Uncomment the following 


    // implementation of the 'create' operation, to create a new 
    // StickyNote resource
    public EndpointReferenceType create(Create c) throws RemoteException
    {
        ResourceContext ctx = ResourceContext.getResourceContext();
        ManyNoteHome home = (ManyNoteHome) ctx.getResourceHome();

        // create a new Sticky note
        ResourceKey key = home.create();
        
        // form an EPR that points to the sticky note
        EndpointReferenceType epr;
        try {
            epr = AddressingUtils.createEndpointReference(ctx, key);
        } catch(Exception e) {
            throw new RemoteException("Could not form an EPR to new counter: "+e);
        }

        return epr;
    }

// END OF EXERCISE 2 ADDITIONS


}
