









package org.globus.tutorial.stickynote;

import javax.xml.namespace.QName;


public interface StickyNoteConstants
{

    static final String STICKY_NS="http://tutorial.globus.org/stickynote";
    static final QName RP_SET = new QName(STICKY_NS,"StickyNoteResourceProperties");
    static final QName NOTECONTENT_RP = new QName(STICKY_NS,"noteContent");

// EXERCISE 4 (completed) : Uncomment the following 

    static final QName LAST_MODIFIED_RP = new QName(STICKY_NS,"lastModified");

// END OF EXERCISE 4 ADDITIONS


}
