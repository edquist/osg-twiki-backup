#!/usr/bin/perl

$DO = 1;

#$me = "lchitnis";
$me = "train33";
%appdirs = ("ufgrid05.phys.ufl.edu" => "/raid/raid4/eo/app/", 
	    "citgrid3.cacr.caltech.edu" => "/raid1/OSG_APP/");
#	    "ll03.alliance.unm.edu" => "/Grid2003/app",
#	    "agridgk01.usatlas.bnl.gov" => "/usatlas/projects/Grid3");
$localdir =`pwd`;
chomp($localdir);


$submit = "condor_submit";
$num = 1000;
@files = ("prime");

&Main;

sub Main {
	if(@ARGV != 1) {
		print("Usage: $0 <task number> \n\t1 - Make your workspace (create dir)\n\t2 - Copy exes\n\t3 - Run prime jobs\n\t4 - Grep output\n\t5 - Cleanup (Remove dir)\n");
		exit(1);
	}
	$task = $ARGV[0];
	if($task == 1) {
		&makedir;
	}
	elsif($task == 2) {
		&copy;
	}
	elsif($task == 3) {
		&run_prime($num);
	}
	elsif($task == 4) {
		&grep_files;
	}
	elsif($task == 5) {
		&cleanup;
	}
}

sub grep_files {
	$result = `grep NO output/$num.*.out 2>/dev/null`;
	if($? != 0) {
		print "The output files are missing. Run the prime jobs\n";
		exit(1);
	}
	if($result eq '') {
		print "The number $num is a prime\n";
	}
	else {
		print "The number $num is not a prime\n";
	}
}

sub run_prime {
 	$root = int(sqrt($num));
	$inc = 10;

	$njobs = int(($root - 2)/$inc) + 1;

	$start = 2;
	$j = 0;
	@sites = %appdirs;
        for($i = 0; $i < $njobs; ++$i) {
		$end = $start + $inc;
		if($end > $root) {
			$end = $root;
		}
		execute("$submit -a \"arguments = $num $start $end\" -a \"output = output/$num.$start.out\" -a \"grid_resource = gt2 $sites[$j]/jobmanager\" -a \"executable = $sites[$j + 1]/prime\" sub");
		$j = ($j + 2) % @sites;
		$start = $end + 1;
	}
}

sub makedir {
	for $site (keys(%appdirs)) {
		print "\nCreating directory $site:$appdirs{$site}/$me\n";
		foreach $file (@files) {
			execute("globus-job-run $site /bin/mkdir $appdirs{$site}/$me");
		}
	}
}

sub copy {
	for $site (keys(%appdirs)) {
		print "\nCopying files to $site\n";
		foreach $file (@files) {
			execute("globus-url-copy file://$localdir/$file gsiftp://$site/$appdirs{$site}/$me/$file");
			execute("globus-job-run $site /bin/chmod +x $appdirs{$site}/$me/$file");
		}
	}
}

sub cleanup {
	for $site (keys(%appdirs)) {
		print "\nDeleting directory $site:$appdirs{$site}/$me\n";
		foreach $file (@files) {
			execute("globus-job-run $site /bin/rm -rf $appdirs{$site}/$me");
		}
	}
}

sub execute {
	my($command) = $_[0];
	print($command, "\n");
	if($DO == 1) {
		system($command);
	}
}
