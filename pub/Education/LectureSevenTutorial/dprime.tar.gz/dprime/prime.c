#include <stdio.h>

int main(int argc, char *argv[])
{	int num, start, end, i;
	if(argc != 4) {
		printf("Usage: %s <number> <start> <end>\n", argv[0]);
		exit(1);
	}
	num = atoi(argv[1]);
	start = atoi(argv[2]);
	end = atoi(argv[3]);
	if(num == 2 || num == 3 || num == 5 || num == 7 || num == 11) {
		printf("YES\n");
		return 0;
	}
	if(num % 2 == 0) {
		printf("NO\n");
		return 0;
	}
	for(i = start;i <= end; ++i) {
		if(i != num && num % i == 0) {
			printf("NO\n");
			exit(0);
		}
	}
	if(i == end + 1)
		printf("YES\n");
	return 0;	
}
