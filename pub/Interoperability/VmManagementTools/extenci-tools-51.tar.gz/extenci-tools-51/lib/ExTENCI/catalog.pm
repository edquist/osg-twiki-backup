use strict;
use warnings;

package ExTENCI::catalog;

use Storable;
use File::Spec;

#
# We can't use normal tie()s for the backing store because they don't
# support references (nested hashes).  We could do clever things with
# key renaming, or just store attribute/value pairs in files.
#
my %catalogBS;
my $catalog = \%catalogBS;
my $catalogDirectory = $ENV{ 'HOME' } . "/.extenci/catalog";
readFromBackingStore( $catalogDirectory, $catalog );

#
# Run the service discovery plugin(s) when loaded.
#
# If we allow Module::Pluggable to require() the plugins, we lose the
# ability to do our own error handling, so we don't.  However, require()
# requires the module name to be a bareword, so we have to use the form
# of eval() which takes a scalar, not a code block.
#
use Module::Pluggable   require         => 0,
                        search_path     => [ 'ExTENCI::Plugin' ],
                        only            => qr/^ExTENCI::Plugin::ServiceDiscovery/;

my @plugins = plugins();
foreach my $plugin (@plugins) {
    if( ! eval( "require $plugin;" ) ) {
        warn( "Service discovery plugin $plugin malformed: can't be require()d.\n" );
        warn( $@ );
        next;
    }

    if( ! $plugin->can( 'discover' ) ) {
        warn( "Service discovery plugin $plugin malformed: can't discover().\n" );
    } else {
        eval( $plugin . q/::discover( \%{$catalog->{ 'service' }});/ );
    }
}    

#
# ExTENCI::catalog::add( objectType, objectID, \%arguments )
#
sub add {
    my $objectType = shift( @_ );
    my $objectID = shift( @_ );
    my %object = @_;
    
    #
    # Rather than figure out how to get them to integrate with
    # service discovery, we forbid changes to the service catalog.
    #
    if( $objectType eq "service" ) { return; }

    #
    # Do some sanity-checking on $objectType and $objectID.
    #
    sanityCheck( 'add', $objectType, $objectID );

    #
    # Write to the backing store.
    #
    if( ! -d "${catalogDirectory}/${objectType}" ) {
        mkdir( "${catalogDirectory}/${objectType}" );
    }
    
    my $fh;
    if( ! open( $fh, '>', "${catalogDirectory}/${objectType}/${objectID}" ) ) {
        die( "Unable to open catalog backing store file '${catalogDirectory}/${objectType}/${objectID}', aborting.\n" );
    }

    #
    # To avoid getting into escaping issues, simply refuse to write
    # annoying values into the catalog.  If the caller doesn't want
    # to die(), they should clean up %arguments.
    #
    foreach my $attribute (keys %object) {
        if( $attribute =~ m/=/ ) { die( "Refusing to write attribute (${attribute}) with embedded '='.\n" ); }
        if( $attribute =~ m/\n/m ) { die( "Refusing to write attribute (${attribute}) with embedded newline.\n" ); }
        my $value = $object{ $attribute };
        if( ! defined( $value ) ) {
            die( "Refusing to write attribute (${attribute}) with undefined value to the catalog.\n" );
        }
        if( $value =~ m/\n/m ) { die( "Refusing to write value (${value}) with embedded newline.\n" ); }
        print( $fh "$attribute = $value\n" );
    }
    
    close( $fh );
    
    $catalog->{ $objectType }->{ $objectID } = \%object;
} # end add() 

#
# ExTENCI::catalog::list( objectType )
#
sub list {
    my( $objectType ) = @_;

    #    
    # Return (a copy of) the keys of the $objectType hash.
    #
    return keys( %{$catalog->{ $objectType }} );
} # end list()

#
# ExTENCI::catalog::get( objectType, objectID )
#
sub get {
    my( $objectType, $objectID ) = @_;

    #
    # Return a reference to (a deep copy) of the object.
    #
    
    if( (! exists( $catalog->{ $objectType } )) ) {
        # warn( "No objects of type '$objectType' exist in the catalog.\n" );
        return undef;
    }
    
    if( (! exists( $catalog->{ $objectType }->{ $objectID } )) ) {
        # warn( "No object of type '$objectType' identified by '$objectID' exists in the catalog.\n" );
        return undef;
    }
    
    return Storable::dclone( $catalog->{ $objectType }->{ $objectID } );
} # end get()

#
# ExTENCI::catalog::remove( objectType, objectID );
#
sub remove {
    my( $objectType, $objectID ) = @_;

    #
    # Rather than figure out how to get them to integrate with
    # service discovery, we forbid changes to the service catalog.
    #
    if( $objectType eq "service" ) { return; }

    #
    # Do some sanity-checking on $objectType and $objectID.
    #
    sanityCheck( 'remove', $objectType, $objectID );

    #
    # Remove from backing store.
    #
    unlink( "${catalogDirectory}/${objectType}/${objectID}" );

    return delete( $catalog->{ $objectType }->{ $objectID } );
} # end remove()

sub readFromBackingStore {
    my( $catalogDirectory, $catalog, $readFiles ) = @_;
    
    if( ! -d $catalogDirectory ) {
        die( "Catalog backing store directory '$catalogDirectory' does not exist, aborting.\n" );
    }
    
    my $dh = undef;
    if( ! opendir( $dh, $catalogDirectory ) ) {
        die( "Unable to open catalog backing store directory '$catalogDirectory': '$!', aborting.\n" );
    }
    
    while( my $entry = readdir( $dh ) ) {
        if( $entry eq '.' || $entry eq '..' ) { next; }
        if( -d "${catalogDirectory}/${entry}" ) {
            #
            # Note that our "default plugin" for service discovery occurs
            # here, where we read the 'service' directory.
            #
            readFromBackingStore( "${catalogDirectory}/${entry}", \%{$catalog->{ $entry }}, 1 );
        } else {
            if( ! $readFiles ) { next; }
            
            my $fh = undef;
            if( ! open( $fh, '<', "${catalogDirectory}/${entry}" ) ) {
                warn( "Failed to open catalog backing store file '${catalogDirectory}/${entry}', skipping.\n" );
                next;
            }
            
            while( my $line = <$fh> ) {
                if( $line =~ /^\s*$/ ) { next; }
                if( $line =~ /^\s*\#/ ) { next; }

                if( $line =~ m/^\s*([^ =]+)\s*=\s*(.*)$/ ) {
                    my $attribute = $1;
                    my $value = $2;
                    
                    # print( "Adding '$attribute' as '$value' to '${entry}'.\n" );
                    $catalog->{ $entry }->{ $attribute } = $value;
                }
            }
            
            close( $fh );
        }
    }
    
    closedir( $dh );
} # end readFromBackingStore()

sub sanityCheck {
    my( $verb, $objectType, $objectID ) = @_;
    
    my @dirs = File::Spec->splitdir( $objectType );
    if( scalar( @dirs ) > 1 ) { die( "Refusing to $verb an object whose type includes a directory separator (${objectType}).\n" ); }
    
    @dirs = File::Spec->splitdir( $objectID );
    if( scalar( @dirs ) > 1 ) { die( "Refusing to $verb an object whose ID includes a directory separator (${objectID}).\n" ); }
}

1;
