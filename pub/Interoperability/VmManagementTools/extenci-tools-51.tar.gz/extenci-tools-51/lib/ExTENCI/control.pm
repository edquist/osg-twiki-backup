use strict;
use warnings;

package ExTENCI::control;

use IPC::Open3;
use Symbol;
use File::Temp;

use ExTENCI::catalog;
use ExTENCI::verify;

#
# ExTENCI::control::start( stagedID, & instanceID ) [handles errors in the usual way].
# On success, it also sets * instanceID appropriately.
#
sub start {
    my( $stagedID, $instanceIDRef ) = @_;

    #
    # Extract the staged image and its corresponding service from the catalog.
    #
    my $stagedImage = ExTENCI::catalog::get( 'staged', $stagedID );
    if( ! defined( $stagedImage ) ) {
        die( "No staged image '$stagedID' in the catalog, aborting.\n" );
    }
    
    my $serviceID = $stagedImage->{ 'service' };
    if( ! defined( $serviceID ) ) {
        die( "Image '$stagedID' staged to undefined service, aborting.\n" );
    }
    
    my $service = ExTENCI::catalog::get( 'service', $serviceID );
    if( ! defined( $service ) ) {
        die( "No service '$serviceID' defined by the catalog, aborting.\n" );
    }

    #
    # Dispatch based on the service's protocol.
    #
    my %dispatch = ( 'EC2' => \& ec2_start );
    
    my $controlProtocol = $service->{ 'ControlProtocol' };
    if( defined( $dispatch{ $controlProtocol } ) ) {
        my %instance = $dispatch{ $controlProtocol }( $stagedID, $stagedImage, $serviceID, $service, $instanceIDRef );
        $instance{ 'service' } = $serviceID;
        ExTENCI::catalog::add( 'instance', ${$instanceIDRef}, %instance );
        return %instance;
    } else {
        die( "Unknown control protocol '$controlProtocol' required for service '$service', aborting.\n" );
    }    
} # end start()

#
# ExTENCI::control::status( instanceID ) ...
#
sub status {
    my( $instanceID ) = @_;

    #
    # Extract the instance and its corresponding service from the catalog.
    #
    my $instance = ExTENCI::catalog::get( 'instance', $instanceID );
    if( ! defined( $instance ) ) {
        die( "No instance '$instanceID' in the catalog, aborting.\n" );
    }

    my $serviceID = $instance->{ 'service' };
    if( ! defined( $serviceID ) ) {
        die( "No service defined for instance ID '$instanceID', aborting.\n" );
    }
    
    my $service = ExTENCI::catalog::get( 'service', $serviceID );
    if( ! defined( $service ) ) {
        die( "No service '$serviceID' defined by the catalog, aborting.\n" );
    }

    #
    # Dispatch based on the service's protocol.
    #
    my %dispatch = ( 'EC2' => \& ec2_status );

    my $controlProtocol = $service->{ 'ControlProtocol' };
    if( defined( $dispatch{ $controlProtocol } ) ) {
        return $dispatch{ $controlProtocol }( $instanceID, $instance, $serviceID, $service );
    } else {
        die( "Unknown control protocol '$controlProtocol' required for service '$service', aborting.\n" );
    }    
} # end status()

#
# ExTENCI::control::stop( instanceID ) [handles errors in the usual way].
#
sub stop {
    my( $instanceID ) = @_;
    
    #
    # Extract the instance and its corresponding service from the catalog.
    #
    my $instance = ExTENCI::catalog::get( 'instance', $instanceID );
    if( ! defined( $instance ) ) {
        die( "No instance '$instanceID' in the catalog, aborting.\n" );
    }

    my $serviceID = $instance->{ 'service' };
    if( ! defined( $serviceID ) ) {
        die( "No service defined for instance ID '$instanceID', aborting.\n" );
    }
    
    my $service = ExTENCI::catalog::get( 'service', $serviceID );
    if( ! defined( $service ) ) {
        die( "No service '$serviceID' defined by the catalog, aborting.\n" );
    }

    #
    # Dispatch based on the service's protocol.
    #
    my %dispatch = ( 'EC2' => \& ec2_stop );

    my $controlProtocol = $service->{ 'ControlProtocol' };
    if( defined( $dispatch{ $controlProtocol } ) ) {
        my $removed = $dispatch{ $controlProtocol }( $instanceID, $instance, $serviceID, $service );
        if( $removed ) {
            ExTENCI::catalog::remove( 'instance', $instanceID );
        } else {
            warn( "Failed to remove instance $instanceID.\n" );
        }
    } else {
        die( "Unknown control protocol '$controlProtocol' required for service '$service', aborting.\n" );
    }
} # end stop()

#
# We unashamedly adopt the Condor job status codes as our standard.
#

sub UNKNOWN { 0; }
sub IDLE { 1; }
sub RUNNING { 2; }
sub REMOVED { 3; }
sub COMPLETED { 4; }
sub HELD { 5; }
sub OUTPUT { 6; }

sub jobStatusToString {
    my( $jobStatus ) = @_;
    if( $jobStatus == 0 ) {
        return "in an unknown state";
    } elsif( $jobStatus == 1 ) {
        return "idle (starting up)";
    } elsif( $jobStatus == 2 ) {
        return "running";
    } elsif( $jobStatus == 3 ) {
        return "removed (shutting down)";
    } elsif( $jobStatus == 4 ) {
        return "completed (shutting down)";
    } elsif( $jobStatus == 5 ) {
        return "held";
    } elsif( $jobStatus == 6 ) {
        return "transferring output";
    } else {
        return "in unknown state $jobStatus";
    }
} # end jobStatusToString()

sub ec2_start {
    my( $stagedID, $stagedImage, $serviceID, $service, $instanceIDRef ) = @_;
    my %instance;

    #
    # We need to store the private key somewhere in order to SSH into
    # the newly-created VMs.  (FutureGrid-Nimbus-Alamo seems willing to
    # create keypairs now.)
    #
    my( $tfh, $temporaryFile ) = tmpnam();
    $instance{ 'keypairFile' } = $temporaryFile;
    close( $tfh );

    #
    # Because we can upload the same image to muliple services, the ID
    # the service assigns to it may conflict the ID from another service.
    # (Services which just use the filename will conflict quite often, since
    # we name the file after the image.)  Instead, record the service's
    # non-unique ID in each staged image in the catalog.
    #
    my $serviceImageID = $stagedImage->{ 'stagedID' };
    
    #
    # Construct the Condor submit file.
    #
    my $gridResource = verifyValue( $service, 'ControlEndpoint' );
    my $instanceType = verifyValue( $stagedImage, 'InstanceType' );
    my $accessKeyFile = verifyFileValue( $service, 'AWS_AccessKeyFile' );
    my $secretKeyFile = verifyFileValue( $service, 'AWS_SecretKeyFile' );

    my $submitFile = qq#
universe                = grid
grid_resource           = ec2 $gridResource

executable              = /bin/true

ec2_ami_id              = $serviceImageID
ec2_instance_type       = $instanceType

ec2_access_key_id       = $accessKeyFile
ec2_secret_access_key   = $secretKeyFile

ec2_keypair_file        = $temporaryFile

queue
#;

    #
    # Submit the job.
    #
    ${$instanceIDRef} = submitCondorJob( $submitFile );

    return %instance;
} # end ec2_start()    

sub submitCondorJob {
    my( $submitFile ) = @_;
    
    my( $in, $out, $err ) = ( undef, undef, gensym() );
    my $pid = open3( $in, $out, $err, 'condor_submit' );
    
    print( $in $submitFile );
    close( $in );
    
    my( $output, $error );
    while( my $line = <$out> ) { $output .= $line; }
    while( my $line = <$err> ) { $error .= $line; }
    
    if( defined( $error ) ) {
        if( defined( $output ) ) { print( $output ); }
        print( STDERR $error );
        die( "Failed to submit Condor job, aborting.\n" );
    }
    
    if( $output =~ m/^1 job\(s\) submitted to cluster (\d+).$/m ) {
        return $1;
    } else {
        die( "Unable to find Condor job ID in '$output', aborting.\n" );
    }        
} # end submitCondorJob()

sub ec2_status {
    my( $instanceID, $instance, $serviceID, $service ) = @_;

    my( $in, $out, $err ) = ( undef, undef, gensym() );
    my @args = ( 
                 '-format', "%s ", 'JobStatus',
                 '-format', "%s ", 'EC2RemoteVirtualMachineName',
                 '-format', '\n', 'dummy',
                 '-constraint', "ClusterId == $instanceID" );
    my $pid = open3( $in, $out, $err, 'condor_q', @args );
    
    my( $output, $error );
    while( my $line = <$out> ) { $output .= $line; }
    while( my $line = <$err> ) { $error .= $line; }

    if( defined( $error ) ) {
        if( defined( $output ) ) { print( $output ); }
        print( STDERR $error );
        return 1;
    }

    if( ! defined( $output ) ) {
        print( "Unexpected silence from condor_q, status unknown.\n" );
        return 0;
    }        

    chomp( $output );
    my( $jobStatus, $rVM ) = split( / /, $output );
    if( $jobStatus !~ m/^(\d+)$/m ) {
        warn( "Unexpected output from condor_q.\n" );
        print( $output );
        return 0;
    }    

    #
    # Write some connectivity information to the catalog.
    #
    if( defined( $rVM ) && $rVM ne '' ) {
        $instance->{ 'InstanceHostName' } = $rVM;
        ExTENCI::catalog::add( 'instance', $instanceID, %{$instance} );
    }
    
    return $jobStatus;
} # end ec2_status()

sub ec2_stop {
    my( $instanceID, $instance, $serviceID, $service ) = @_;

    my( $in, $out, $err ) = ( undef, undef, gensym() );
    my $pid = open3( $in, $out, $err, 'condor_rm', $instanceID );
    
    my( $output, $error );
    while( my $line = <$out> ) { $output .= $line; }
    while( my $line = <$err> ) { $error .= $line; }

    if( defined( $error ) ) {
        if( defined( $output ) ) { print( $output ); }
        print( STDERR $error );
        return 0;
    }

    if( $output =~ m/^Cluster (\d+) has been marked for removal.$/m ) {
        #
        # Remove the instance's keypairFile.
        #
        if( -e $instance->{ 'keypairFile' } ) {
            unlink( $instance->{ 'keypairFile' } );
        }
    
        return 1;
    } else {
        warn( "Unexpected output from condor_rm.\n" );
        print( $output );
        return 0;
    }    
} # end ec2_stop()

1;
