use strict;
use warnings;

package ExTENCI::verify;

#
# Because perl hates you: "There are no relative packages." -- perlmod
#
our( @ISA, @EXPORT, @EXPORT_OK );
BEGIN {
    require Exporter;
    @ISA = qw( Exporter );
    @EXPORT = qw( verifyValue verifyFileValue );
    @EXPORT_OK = qw( );
};

sub verifyValue {
    my( $hashref, $key ) = @_;
    my $value = $hashref->{ $key };
    if( ! defined( $value ) ) {
        die( "Attribute '$key' is not defined, aborting.\n" );
    }
    return $value;
} # end verifyValue()

sub verifyFileValue {
    my( $hashref, $key ) = @_;
    my $value = verifyValue( $hashref, $key );
    if( ! -e $value ) {
        #
        # Check for ~ and replace with the user's home directory.
        # WARNING: For some reason, nothing is set in the environment.
        # This is a clumsy hack, but it should work, and eliminates the
        # need for File::HomeDir.
        #
        my( $userName ) = getpwuid( $> );
        if( defined( $userName ) ) {
            my $homeDirectory = "/home/${userName}";
            my $expandedValue = $value;
            $expandedValue =~ s/^~/${homeDirectory}/;
            if( -e $expandedValue ) { return $expandedValue; }
        }
        die( "File attribute '$key' with value '$value' does not point to an existing file, aborting.\n" );
    }
    return $value;
} # end verifyFileValue()

1;
