use strict;
use warnings;

package ExTENCI::stage;

use Symbol;
use IPC::Open3;
use File::Temp;

use File::Basename;
use File::Copy;
use File::Path;

use ExTENCI::catalog;
use ExTENCI::verify;

my $s3_manifestDir = $ENV{ 'HOME' } . "/.extenci/s3/manifests";

#
# ExTENCI::stage::add() ...
#
sub add {
    my( $stagedIDRef, $imageID, $serviceID, @serviceSpecificArgs ) = @_;

    my $image = ExTENCI::catalog::get( 'image', $imageID );
    if( ! defined( $image ) ) {
        die( "No image '$imageID' found in catalog, aborting.\n" );
    }

    my $service = ExTENCI::catalog::get( 'service', $serviceID );
    if( ! defined( $service ) ) {
        die( "No service '$serviceID' defined by the catalog, aborting.\n" );
    }
    
    my %dispatch = ( 'S3' => \& s3_add );
    my $transferProtocol = $service->{ 'TransferProtocol' };
    if( defined( $dispatch{ $transferProtocol } ) ) {
        my %stagedImage = $dispatch{ $transferProtocol }( $imageID, $image, $serviceID, $service, $stagedIDRef, @serviceSpecificArgs );
        if( defined( ${$stagedIDRef} ) ) {
            # Necessary for starting the image.
            $stagedImage{ 'stagedID' } = ${$stagedIDRef};
            ${$stagedIDRef} .= '@' . $serviceID;
            $stagedImage{ 'service' } = $serviceID;
            $stagedImage{ 'image' } = $imageID;
            ExTENCI::catalog::add( 'staged', ${$stagedIDRef}, %stagedImage );
            return %stagedImage;
        }
    } else {
        die( "Unknown transfer protocol '$transferProtocol' required for service '$service', aborting.\n" );
    }
} # end add()

sub convertFileNameToValue {
    my( $fileName ) = @_;
    
    if( ! -e $fileName ) {
        die( "Aborting instead of trying to read non-existent file '$fileName'.\n" );
    }
    
    my $fh;
    if( ! open( $fh, '<', $fileName ) ) {
        die( "Unable to open '$fileName' ('$!'); aborting.\n" );
    }
    
    my $contents;
    while( my $line = <$fh> ) {
        $contents .= $line;
    }

    close( $fh );
    
    chomp( $contents );
    return $contents;
} # end convertFileNameToValue()

sub expect {
    my( $success, $resultRef, $command, @args ) = @_;
    
    my( $in, $out, $err ) = ( undef, undef, gensym() );
    my $pid = open3( $in, $out, $err, $command, @args );
    
    my( $output, $error );
    while( my $line = <$out> ) { $output .= $line; }
    while( my $line = <$err> ) { $error .= $line; }

    if( defined( $error ) ) {
        if( defined( $output ) ) { print( $output ); }
        die( $error . "\n" );
    }

    if( (! defined( $output )) ) {
        if( defined( $success ) ) {
            die( "Unexpected lack of output from $command.\n" );
        } else {
            ${$resultRef} = undef;
            return;
        }            
    }

    if( $output =~ $success ) {
        ${$resultRef} = $1;
    } else {
        warn( "Unexpected output from $command.\n" );
        print( $output );
        die( "\n" );
    }
} # end expect()

sub s3_add {
    my( $imageID, $image, $serviceID, $service, $stagedIDRef, @ssArgs ) = @_;

    my $style = verifyValue( $service, "S3_Style" );
    my %dispatch = ( 'Amazon'           => \& s3_add_amazon,
                     'Nimbus'           => \& s3_add_nimbus,
                     'Nimbus-Register'  => \& s3_add_nimbus_register,
                   );
    return $dispatch{ $style }( @_ );
} # end s3_add()

sub s3_add_nimbus_register {
    my( $imageID, $image, $serviceID, $service, $stagedIDRef, @ssArgs ) = @_;
    
    #
    # Upload to S3.
    #
    my %stagedImage = s3_add_nimbus( @_ );
    
    #
    # Register in EC2.
    #
    my $userID = convertFileNameToValue( verifyFileValue( $service, "AWS_UserIDFile" ) );
    my $accessKeyFile = verifyFileValue( $service, 'AWS_AccessKeyFile' );
    my $secretKeyFile = verifyFileValue( $service, 'AWS_SecretKeyFile' );
    my $serviceURL = verifyValue( $service, 'ControlEndpoint' );
    
    my $registeredAMI = undef;
    my $command = qq/extenci-ec2-register /
                . qq/--access-key-file ${accessKeyFile} /
                . qq/--secret-key-file ${secretKeyFile} /
                . qq/--url ${serviceURL} /
                . qq# VMS/${userID}/${imageID} #;
    my $amiFD;
    if( ! open( $amiFD, "$command |" ) ) {
        die( "Failed to run '$command', aborting.\n" );
    }
    while( my $line = <$amiFD> ) {
        if( $line =~ m/^AMI ID = / ) {
            $registeredAMI = $line;
            chomp( $registeredAMI );
            $registeredAMI =~ s/^AMI ID = //;
        }
    }
    close( $amiFD );
    if( ! defined( $registeredAMI ) ) {
        die( "Failed to register AMI, aborting.\n" );
    }    
    
    ${$stagedIDRef} = $registeredAMI;
    
    return %stagedImage;
} # end s3_add_nimbus_register()

sub s3_add_nimbus {
    my( $imageID, $image, $serviceID, $service, $stagedIDRef, @ssArgs ) = @_;
    
    my %stagedImage;
    
    my $userID = convertFileNameToValue( verifyFileValue( $service, "AWS_UserIDFile" ) );
    my $accessKeyFile = verifyFileValue( $service, 'AWS_AccessKeyFile' );
    my $secretKeyFile = verifyFileValue( $service, 'AWS_SecretKeyFile' );
    my $imageFileName = verifyFileValue( $image, 'filename' );
    my $bucketName = verifyValue( $service, 'S3_BucketName' );
    my $serviceURL = verifyValue( $service, 'TransferEndpoint' );
    
    #
    # Services with a registration requirement must have a 1-1 mapping between
    # registrations and images (unless we want to track that ourselves).  For
    # consistency, make _all_ uploaded image (file) names, as well as the
    # corresponding staged ID, unique.
    #
    my $uploadCount = scalar( ExTENCI::catalog::list( 'staged' ) );
    $imageID .= "-${uploadCount}";
    #
    # Nimbus decompresses gzipped images on the fly, but requires
    # that they have that suffix.  We should actually check for
    # magic bytes, but since they don't...
    #
    if( $imageFileName =~ m/\.gz$/ ) { $imageID .= ".gz"; }
    my $key = "VMS/${userID}/${imageID}";
    
    #
    # Call the boto wrapper.
    #
    my $command = qq/extenci-s3-cp /
                . qq/--access-key-file ${accessKeyFile} /
                . qq/--secret-key-file ${secretKeyFile} /
                . qq/--url ${serviceURL} /
                . qq/--bucket ${bucketName} /
                . qq/${imageFileName} /
                . qq#--key $key #;
    my $rv = system( $command );
    if( $rv != 0 ) {
        die( "Failed to run '$command', aborting.\n" );
    }
    
    #
    # Update catalog data.
    #
    $stagedImage{ 'Key' } = $key;

    $stagedImage{ 'InstanceType' } = "m1.small";
    if( defined( $ssArgs[0] ) ) {
        $stagedImage{ 'InstanceType' } = $ssArgs[0];
    }
    
    ${$stagedIDRef} = $imageID;
    return %stagedImage;
} # end s3_add_nimbus()

sub s3_add_amazon {
    my( $imageID, $image, $serviceID, $service, $stagedIDRef, @ssArgs ) = @_;

    my %stagedImage;

    #
    # Prep.
    #
    my $userID = convertFileNameToValue( verifyFileValue( $service, "AWS_UserIDFile" ) );
    my $serviceKey = verifyFileValue( $service, "AWS_ServiceKey" );
    my $bucketName = verifyValue( $service, "S3_BucketName" );
    my $imageFileName = verifyFileValue( $image, 'filename' );

    #
    # Configure.
    #
    $ENV{ 'EC2_URL' } = verifyValue( $service, 'ControlEndpoint' );
    $ENV{ 'S3_URL' } = verifyValue( $service, 'TransferEndpoint' );
    $ENV{ 'EC2_CERT' } = verifyFileValue( $service, 'AWS_PublicKeyFile' );
    $ENV{ 'EC2_PRIVATE_KEY' } = verifyFileValue( $service, 'AWS_PrivateKeyFile' );
        
    #
    # The euca2ools won't take filenames for the private and access keys;
    # the actual text has to be passed to then.  Because almost all OSes
    # allow anyone to see the command line of any process, we pass them
    # through the environment.  On some OSes, this is also insecure.
    #
    # If this actually worries anyone, we can reimplement with a less-
    # broken tool or API.
    #
    $ENV{ 'EC2_ACCESS_KEY' } = convertFileNameToValue( verifyFileValue( $service, 'AWS_AccessKeyFile' ) );
    $ENV{ 'EC2_SECRET_KEY' } = convertFileNameToValue( verifyFileValue( $service, 'AWS_SecretKeyFile' ) );

    # foreach my $var (keys %ENV) {
    #     if( $var =~ /^(S3)|(EC2)/ ) { print( "${var} = " . $ENV{ $var } . "\n" ); }
    # }

    #
    # See commentary in s3_add_nimbus().  Since the euca2ools don't seem to
    # have it as an option, point them at a convenient symlink, instead.
    #
    my $uploadCount = scalar( ExTENCI::catalog::list( 'staged' ) );
    my $uniqueIFN = "${imageFileName}-${uploadCount}";
    #
    # FIXME: should we actually check for this, or just be sure to
    # unlink our symlinks when we're done with them?
    #
    if( -e $uniqueIFN ) {
        if( ! ( -l $uniqueIFN && readlink( $uniqueIFN ) eq $imageFileName ) ) {
            die( "Unable to symlink unique image file name ('${uniqueIFN}'), as a file already exists there: aborting.\n" );
        }
    } else {
        if( symlink( $imageFileName, $uniqueIFN ) != 1 ) {
            die( "Unable to symlink unique image file name ('${uniqueIFN}'): '$!', aborting.\n" );
        }
    }        
    $imageFileName .= "-${uploadCount}";
    
    #
    # Bundle.
    #
    my $temporaryDirectory = File::Temp->newdir();
    my @bundleArguments = ( '-u'        => $userID,
                            '-i'        => $imageFileName,
                            '-d'        => $temporaryDirectory->dirname(),
                            '--ec2cert' => $serviceKey );
    # print( "euca-bundle-image " . join( " ", @bundleArguments ) . "\n" );
    my $manifestFile = undef;
    my $bundleSuccess = qr/^Generating manifest (.+)$/m;
    expect( $bundleSuccess, \$manifestFile, 'euca-bundle-image', @bundleArguments );
    if( defined( $manifestFile ) ) {
        print( "Bundled image with manifest $manifestFile...\n" );
    } else {
        die( "Unable to bundle image, aborting.\n" );
    }
    
    #
    # Save a copy of the manifest to the catalog to simplify s3_remove().
    #
    if( ! -d $s3_manifestDir ) {
        mkpath( $s3_manifestDir );
    }

    my $localManifest = $s3_manifestDir . "/" . basename( $manifestFile );
    if( copy( $manifestFile, $localManifest ) == 0 ) {
        die( "Unable to copy '$manifestFile' to '$localManifest', aborting.\n" );
    }        
    $stagedImage{ 'manifest' } = $localManifest;

    #
    # Upload.
    #
    my @uploadArguments = ( '-m'    => $manifestFile,
                            '-b'    => $bucketName );
    my $bundleName = undef; 
    my $uploadSuccess = qr/^Uploaded image as (.+)$/m;
    # print( "euca-upload-bundle " . join( " ", @uploadArguments ) . "\n" );
    expect( $uploadSuccess, \$bundleName, 'euca-upload-bundle', @uploadArguments );
    if( defined( $bundleName ) ) {
        print( "Uploaded image to $bundleName...\n" );
    } else {
        die( "Unable to upload image, aborting.\n" );
    }
    
    #
    # Register.
    #
    my @registerArguments = ( $bundleName );
    my $registerSuccess = qr/^IMAGE\t(.+)$/m;
    # print( "euca-register " . join( " ", @registerArguments ) . "\n" );    
    expect( $registerSuccess, $stagedIDRef, 'euca-register', @registerArguments );
    if( defined( ${$stagedIDRef} ) ) {
        print( "Registered image $imageID as ${$stagedIDRef}.\n" );
    } else {
        print( STDERR "Unable to register image, attempting to delete bundle...\n" );
        my $deleteResults = undef;
        my $deleteSuccess = undef;
        expect( $deleteSuccess, \$deleteResults, 'euca-delete-bundle', @uploadArguments );
        die( "Deleted uploaded bundle.  Aborting.\n" );
    }
    
    #
    # Update catalog data.
    #
    $stagedImage{ 'InstanceType' } = "m1.small";
    if( defined( $ssArgs[0] ) ) {
        $stagedImage{ 'InstanceType' } = $ssArgs[0];
    }

    #
    # Return staged image data.
    #
    return %stagedImage;
} # end s3_add_amazon()

#
# ExTENCI::stage::remove( stagedID ) ...
#
# On success or failure, set * removedID to the stagedID that the 
# vmCatalogID and service pair generated in their previous call to 
# ExTENCI::stage::add().
#

sub remove {
    my( $stagedID ) = @_;
    my $stagedIDRef = \$stagedID;
    if( scalar( @_ ) == 3 ) {
        my( $imageID, $serviceID );
        ( $imageID, $serviceID, $stagedIDRef ) = @_;

        $stagedID = undef;
        my @stagedIDs = ExTENCI::catalog::list( 'staged' );
        foreach my $checkID (@stagedIDs) {
            my $stagedImage = ExTENCI::catalog::get( 'staged', $checkID );
            if( $stagedImage->{ 'service' } eq $serviceID
             && $stagedImage->{ 'image' } eq $imageID ) {
                $stagedID = $checkID;
            }
        }
        if( defined( $stagedID ) ) {
            ${$stagedIDRef} = $stagedID;
        } else {
            warn( "No record of image $imageID staged on service $serviceID found.  Unable to remove.\n" );
            return;
        }
    }

    my $stagedImage = ExTENCI::catalog::get( 'staged', $stagedID );
    if( ! defined( $stagedImage ) ) {
        die( "No staged image '$stagedID' found in catalog, aborting.\n" );
    }
    my $serviceID = $stagedImage->{ 'service' };
    my $service = ExTENCI::catalog::get( 'service', $serviceID );
    if( ! defined( $service ) ) {
        die( "No service '$serviceID' found in catalog, aborting.\n" );
    }

    #
    # The local (catalog) stagedID distinguishes between different
    # sites which host the same image.  We store the real name
    # in the staged image.
    #
    my $serviceStagedID = $stagedImage->{ 'stagedID' };
    
    #
    # To 'remove' the staged image ($stagedID) means different things
    # to different services.  In all cases, however, a removed image
    # should result in no cloud resources being consumed by the image.
    #    
    my %dispatch = ( 'S3' => \& s3_remove );
    my $transferProtocol = $service->{ 'TransferProtocol' };
    if( defined( $dispatch{ $transferProtocol } ) ) {
        my $result = $dispatch{ $transferProtocol }( $stagedID, $service, $serviceStagedID );
        if( $result ) {
            ExTENCI::catalog::remove( 'staged', $stagedID, $stagedID );
            return 1;
        } else {
            return 0;
        }
    } else {
        die( "Unknown transfer protocol '$transferProtocol' required for service '$service', aborting.\n" );
    }
} # end remove()

sub s3_remove {
    my( $stagedID, $service, $serviceStagedID ) = @_;
    my $style = verifyValue( $service, "S3_Style" );
    my %dispatch = ( 'Amazon'           => \& s3_remove_amazon,
                     'Nimbus'           => \& s3_remove_nimbus,
                     'Nimbus-Register'  => \& s3_remove_nimbus_register,
                   );
    return $dispatch{ $style }( $stagedID, $service, $serviceStagedID );
} # end s3_remove()

sub s3_remove_amazon {
    my( $stagedID, $service, $serviceStagedID ) = @_;

    #
    # We unregister the AMI and then remove the corresponding bundle from S3.
    # The s3_add() function ensures this 1-1 mapping so that we can always
    # safely remove the corresponding bundle, and ensure that no service
    # resources are being used after a successful call of remove().
    #

    #
    # Prep.
    #
    my $userID = convertFileNameToValue( verifyFileValue( $service, "AWS_UserIDFile" ) );
    my $serviceKey = verifyFileValue( $service, "AWS_ServiceKey" );
    my $bucketName = verifyValue( $service, "S3_BucketName" );

    #
    # Configure.
    #
    $ENV{ 'EC2_URL' } = verifyValue( $service, 'ControlEndpoint' );
    $ENV{ 'S3_URL' } = verifyValue( $service, 'TransferEndpoint' );
    $ENV{ 'EC2_CERT' } = verifyFileValue( $service, 'AWS_PublicKeyFile' );
    $ENV{ 'EC2_PRIVATE_KEY' } = verifyFileValue( $service, 'AWS_PrivateKeyFile' );
        
    #
    # The euca2ools won't take filenames for the private and access keys;
    # the actual text has to be passed to then.  Because almost all OSes
    # allow anyone to see the command line of any process, we pass them
    # through the environment.  On some OSes, this is also insecure.
    #
    # If this actually worries anyone, we can reimplement with a less-
    # broken tool or API.
    #
    $ENV{ 'EC2_ACCESS_KEY' } = convertFileNameToValue( verifyFileValue( $service, 'AWS_AccessKeyFile' ) );
    $ENV{ 'EC2_SECRET_KEY' } = convertFileNameToValue( verifyFileValue( $service, 'AWS_SecretKeyFile' ) );

    # foreach my $var (keys %ENV) {
    #     if( $var =~ /^(S3)|(EC2)/ ) { print( "${var} = " . $ENV{ $var } . "\n" ); }
    # }

    #
    # Acquire the ID of the corresponding bundle.
    #
    my @diArguments = ( $serviceStagedID );
    my $bundleID = undef;
    my $diSuccess = qr/^IMAGE\s+$serviceStagedID\s+([^\s]+)/;
    expect( $diSuccess, \$bundleID, 'euca-describe-images', @diArguments );
    if( ! defined( $bundleID ) ) {
        warn( "Unable to determine bundle ID for AMI $serviceStagedID.\n" );
        warn( "Declining to remove() staged image.\n" );
        return 0;
    }

    #
    # Unregister the AMI.
    #
    my @deregisterArguments = ( $serviceStagedID );
    my $deregisteredID = undef;
    my $deregisterSuccess = qr/^IMAGE\s+(.+)$/;
    expect( $deregisterSuccess, \$deregisteredID, 'euca-deregister', @deregisterArguments );
    if( defined( $deregisteredID ) ) {
        print( "Deregistered AMI $deregisteredID.\n" );
    } else {
        warn( "Failed to deregister $serviceStagedID.\n" );
        warn( "Declining to remove() staged image.\n" );
        return 0;
    }
    
    #
    # The standard API requires a local copy of the manifest.
    #
    my $stagedImage = ExTENCI::catalog::get( 'staged', $stagedID );
    my $localManifest = $stagedImage->{ 'manifest' };
    
    #
    # Remove the corresponding bundle.
    #
    my( $bucket ) = split( /\//, $bundleID );
    my @deleteArguments = ( '--bucket'      => $bucket,
                            '--manifest'    => $localManifest );
    my $deleteOut = undef;
    my $deleteSuccess = undef;
    expect( $deleteSuccess, \$deleteOut, 'euca-delete-bundle', @deleteArguments );
    if( ! defined( $deleteOut ) ) {
        print( "Deleted the bundle associated with AMI $serviceStagedID.\n" );
        unlink( $localManifest );        
        return 1;
    } else {
        warn( "Failed to delete the bundle ($bundleID) associated with AMI $serviceStagedID.\n" );
        return 0;
    }
} # end s3_remove_amazon()

sub s3_remove_nimbus_register {
    my( $stagedID, $service, $serviceStagedID ) = @_;

    #
    # Unregister in EC2.
    #
    my $userID = convertFileNameToValue( verifyFileValue( $service, "AWS_UserIDFile" ) );
    my $accessKeyFile = verifyFileValue( $service, 'AWS_AccessKeyFile' );
    my $secretKeyFile = verifyFileValue( $service, 'AWS_SecretKeyFile' );
    my $serviceURL = verifyValue( $service, 'ControlEndpoint' );
    print( "Unregistering $serviceStagedID...\n" );
    
    my $registeredAMI = undef;
    my $command = qq/extenci-ec2-deregister /
                . qq/--access-key-file ${accessKeyFile} /
                . qq/--secret-key-file ${secretKeyFile} /
                . qq/--url ${serviceURL} /
                . qq/${serviceStagedID} /;
    my $rv = system( $command );
    if( $rv != 0 ) {
        die( "Command '$command' failed, aborting.\n" );
    }

    s3_remove_nimbus( @_ );
    return 1;
} # end s3_remove_nimbus_register

sub s3_remove_nimbus {
    my( $stagedID, $service ) = @_;

    #
    # Remove the image from S3.
    #
    my $userID = convertFileNameToValue( verifyFileValue( $service, "AWS_UserIDFile" ) );
    my $accessKeyFile = verifyFileValue( $service, 'AWS_AccessKeyFile' );
    my $secretKeyFile = verifyFileValue( $service, 'AWS_SecretKeyFile' );
    my $bucketName = verifyValue( $service, 'S3_BucketName' );
    my $serviceURL = verifyValue( $service, 'TransferEndpoint' );
    
    my $stagedImage = ExTENCI::catalog::get( 'staged', $stagedID );
    my $key = $stagedImage->{ 'Key' };
    print( "Removing ${key} from S3...\n" );

    my $command = qq/extenci-s3-rm /
                . qq/--access-key-file ${accessKeyFile} /
                . qq/--secret-key-file ${secretKeyFile} /
                . qq/--url ${serviceURL} /
                . qq/--bucket ${bucketName} /
                . qq/--key ${key} /;
    my $rv = system( $command );
    if( $rv != 0 ) {
        die( "Failed to run '$command', aborting.\n" );
    }

    return 1;
} # end s3_remove_nimbus

1;
