#
# Handle the common authentication arguments in a secure manner.
#

import optparse

import os
import io
import sys

#
# getSecureFlagsParser() handles EC2 and S3 authentication parameters.
#
def getSecureFlagsParser() :
    op = optparse.OptionParser( add_help_option = False, usage = optparse.SUPPRESS_USAGE )

    op.add_option( '-a', '--access-key-file', dest = 'accessKeyFile',
                   default = os.environ.get( 'ACCESS_KEY_FILE' ) )

    op.add_option( '-s', '--secret-key-file', dest = 'secretKeyFile',
                   default = os.environ.get( 'SECRET_KEY_FILE' ) )
    return op

#
# addS3Options() includes --url because the EC2 version defaults to EC2_URL.
#
def addS3Options( op ) :
    op.add_option( '-u', '--url', dest = 'url',
                   default = os.environ.get( 'S3_URL' ) )

    op.add_option( '-b', '--bucket', dest = 'bucket',
                   default = os.environ.get( 'S3_BUCKET' ) )

    op.add_option( '-k', '--key', dest = 'key' )    
    return op

#
# addEC2Options()
#
def addEC2Options( op ) :
    op.add_option( '-u', '--url', dest = 'url',
                   default = os.environ.get( 'EC2_URL' ) )

    return op

#
# getEC2OptionsParser() is a convenience function.
#
def getEC2OptionsParser() :
    return addEC2Options( getSecureFlagsParser() )

#
# getS3OptionsParser() is a convenience function.
#
def getS3OptionsParser() :
    return addS3Options( getSecureFlagsParser() )

#
# convertFileNameToValue( fileName )
#
def convertFileNameToValue( fileName ) :
    try :
        with io.open( fileName ) as file :
            contents = file.readline()
            contents = contents.rstrip()
            if file.readline() != "" :
                sys.stderr.write( "Warning: '" + fileName + "' has too many lines.\n" )
    except IOError as ioe :
        sys.stderr.write( str( ioe ) + "\n" )
        return None
    return contents

#
# This makes both EC2 and S3 command-line tools easier to use.
#
def parseURL( url ) :
    # Python hates goodness and won't let me use an object -type object
    # to build a struct dynamically.
    class parsedURL( object ) :
        pass
    rv = parsedURL()
    
    if url.startswith( "https://" ) :
        rv.isSecure = True
        url = url[8:]
    elif url.startswith( "http://" ) :
        rv.isSecure = False
        url = url[7:]           
    else :
        return None

    colon = url.rfind( ':' )
    if colon > -1 and colon < len( url ) :
        rv.port = url[(colon + 1):]
        try :
            rv.port = int( rv.port )
        except ValueError as ve :
            sys.stderr.write( "'%s' is not a valid port number.\n" % rv.port )
            return None
        url = url[:colon]
    else :
        rv.port = None

    rv.host = url

    return rv
