use strict;
use warnings;

package ExTENCI::verify;

#
# Because perl hates you: "There are no relative packages." -- perlmod
#
our( @ISA, @EXPORT, @EXPORT_OK );
BEGIN {
    require Exporter;
    @ISA = qw( Exporter );
    @EXPORT = qw( verifyValue verifyFileValue );
    @EXPORT_OK = qw( );
};

sub verifyValue {
    my( $hashref, $key ) = @_;
    my $value =$hashref->{ $key };
    if( ! defined( $value ) ) {
        die( "Attribute '$key' is not defined, aborting.\n" );
    }
    return $value;
} # end verifyValue()

sub verifyFileValue {
    my( $hashref, $key ) = @_;
    my $value = verifyValue( $hashref, $key );
    if( ! -e $value ) {
        die( "File attribute '$key' with value '$value' does not point to an existing file, aborting.\n" );
    }
    return $value;
} # end verifyFileValue()

1;
