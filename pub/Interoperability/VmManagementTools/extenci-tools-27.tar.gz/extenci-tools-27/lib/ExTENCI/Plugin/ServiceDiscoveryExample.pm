use strict;
use warnings;

package ExTENCI::Plugin::ServiceDiscoveryExample;

#
# discover( \%catalog ): no-op.
#
sub discover {
    my( $catalog ) = @_;
}

1;
