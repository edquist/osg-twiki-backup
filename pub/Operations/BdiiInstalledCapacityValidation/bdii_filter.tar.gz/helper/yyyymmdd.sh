#!/bin/sh
fix()
{
        # Replace a space by a 0 in the first argument ${1} passed to this
        # function
        echo ${1/ /0}
}

day=`date +%a`          #Sun - Mon
mm=`date +%m`           #01 to 12
month=`date +%b`        #Apr
dd=`date +%d`           #01 to 31
yyyy=`date +%Y`         #2005
hh=`date +%k`           #00 - 23
hh=`fix "$hh"`
min=`date +%M`          #00 to 59
min=`fix "$min"`
yyyymmdd="$yyyy$mm$dd-$hh:$min"

echo $yyyymmdd
