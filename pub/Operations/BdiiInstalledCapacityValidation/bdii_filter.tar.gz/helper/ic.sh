#!/bin/sh

#Author: Karthik
#Date: Tue, March 3rd 2009
#Purpose: Script to calculate the installed computing capacity (ic) at a site based on the guidelines laid out in the installed capacity document. This script reads the BDII GLUE data (from the BDII webpage) for different T2 sites and then calculates the installed capacity values.
#Pre-requisites: curl (should be executable from command line)
#		 The BDII GLUE data should match a particular format and structure, because the data processing is based on this structure/format
# Input data needed
#		t2.sh - file containing the ic values as maintained by T2 co-ordinators for comparing data
#		llt2.sh - file containing the lower ic limits for filtering data 
#		ult2.sh - file containing the upper ic limits for filtering data 
#		gip.conf - gip configuration file that contains the KSI2K lookup values for different processor models
#		sites.txt - file containing the list of sites along with their FQDN
#
#########################################################################################################

if [ -z $INSTALL_DIR ]; then
        echo "ERROR!!! INSTALL_DIR not set."
        echo "Set the installation directory as shown below and try again."
        echo "export INSTALL_DIR=/absolute/path/to/installation/directory"
        exit 2
fi

yyyymmdd=`$INSTALL_DIR/helper/yyyymmdd.sh` # date and time stamp to be used for the script's log file
logFile="$INSTALL_DIR/log/ic-$yyyymmdd.log"

# Flags to indicate various options/conditions
verbose=0 # verbose output
csv=0 # comma separated values output
format=0 # formatted output
sitenum=0 # counter for site number
allSites=0 # output calculation for all sites or not (default is only output sites supporting ATLAs or CMS VOs)
html=0 # flag to indicate if output needs to be wrapped in html <pre> tags
adjust=0 # flag to indicate if the adjustment % for the installed capacity need to be printed
fqdnFlag=0 # flag indicatin that no fqdn command line option has been given

# usage routine to display usage if the user mis-types options or indicates help using the help flag
usage() {
	echo "Usage: $0 [ options ]"
	echo options
	echo "# Use -v or -verbose or --verbose for verbose mode"
	echo "# use -h or -help or --help for help mode"
	echo "# use either -csv for outputting comma separated values OR -format for formatted output. Only one of -csv or -format is allowed, but not both. Default is -format"
	echo "# use -all to output installed capacity statistics for all sites. The default is to report only for sites that support atlas or cms VOs"
	echo "# use -fqdn to specify an input filename to read the BDII data from. Note: -site option can't be combined with this option"
	echo "# use -adjust to output the percentage by which the bdii data needs to be adjusted so that the installed capacity will fit within the pre-defined bounds"
	echo "# use -html to have the formatted output wrapped in html <pre> tags"
	echo "# If you want the installed capacity of specific sites then you can provide the list of sites using the -site option. This should be provided as the last option. Example: ./ic.sh -format -sites AGLT2 OU_OCHEP_SWT2". Note: This will provide information about all sites that match the pattern. For example -sites AGLT2 WT2 will match AGLT2, MWT2_IU, MWT2_UC, WT2 etc.
}

# Handle command line options and set corresponding flags
while [ $# -gt 0 ] # while more options are available
do
	case $1 in
		-h|--help|-help)
		usage
		exit 0
		;;
		--verbose|-verbose|-v|--v)
		verbose=1
		format=1
		csv=1
		;;
		-csv|--csv)
		csv=1
		;;
		-format|--format)
		format=1
		;;
		-all|--all)
		allSites=1
		;;
		-html|--html)
		html=1
		format=1
		;;
		-fqdn|--fqdn)
		fqdnFlag=1
		# Get input filename
		shift
		inFile=$1	
		[ -z $inFile ] && echo "ERROR!!! You need to specify the absolute path for the fqdn file " && exit 2
		[ ! -r $inFile ] && echo "ERROR!!! Cannot read $inFile" && exit 2
		[ ! -s $inFile ] && echo "ERROR!!! $inFile is empty" && exit 2
		inFileBase=`basename $inFile`
		;;
		-site|--site|-sites|--sites)
		shift
		# Get all site names in one shot using the rest of the arguments
		siteNames=$*
		originalSiteNames=$siteNames
		# check to make sure that this is the last option by grepping for a " -" pattern which indicates another option
		[ `echo $siteNames | grep " -"|wc -l` -eq 1 ] && usage && exit 2
                # make sure fqdn option isn't given if -site is given
		[ $fqdnFlag -eq 1 ] && usage && exit 2
		# shift through rest of the arguments so that we will be done (note that the arguments have already been read in one shot using $* into the variable siteNames) 
		while [ $# -ne 0 ]
		do
			shift
		done
		# substitute all spaces in the list of site names by | so that this could be used in egrep to grep only those sites. Example: AGLT2 OU_OCHEP_SWT2 will become AGLT2|OU_OCHEP_SWT2 which can be used as egrep "AGLT2|OU_OCHEP_SWT2" to select only the matching sites from the file containing the list of all sites
		siteNames=`echo ${siteNames// /|}`
		;;
		# only output the % by which the BDII data need to be adjusted
		--adjust|-adjust) 
		adjust=1
		;;
		*) usage
		exit 2
		;;
	esac
	# Get next option
	shift
done


# verify/adjust flags/options as appropriate
[ $csv -eq 1 ] && [ $format -eq 1 ] && [ $verbose -eq 0 ] && usage && exit 2
[ $csv -eq 1 ] && [ $html -eq 1 ] && [ $verbose -eq 0 ] && usage && exit 2
[ $html -eq 1 ] && [ $verbose -eq 1 ] && usage && exit 2

[ $csv -eq 0 ] && [ $format -eq 0 ] && [ $verbose -eq 0 ] && [ $adjust -eq 0 ] && format=1

[ $html -eq 1 ] && echo "<pre>"
[ $html -eq 1 ] && echo "Installed capacity comparison"

#########################################################################################################

gipconf=$INSTALL_DIR/conf/gip.conf # gip configuration file - used to lookup KSI2K values for various processor models
[ ! -r $gipconf ] && echo "ERROR!!! Cannot read gip configuration file $gipconf" >&2 && exit 2

# source needed setup/configuration files
# calculated ic values will be limited within the ll and ul values
. $INSTALL_DIR/conf/setup.sh # setup file containing installed capacity limits and values maintained by T2 co-ordinators

if [ $fqdnFlag -ne 1 ]; then
	siteFile=$INSTALL_DIR/conf/sites.txt # list of site names and FQDN - needed to get the data from BDII using curl as shown below
	[ ! -r $siteFile ] && echo "ERROR!!! Cannot read input file $siteFile containing site information" >&2 && exit 2
	siteList=`cat $siteFile|egrep "$siteNames"`
	[ `echo "$siteList"|egrep -v ^$|wc -l` -eq 0 ] && echo "No matching sites found for $originalSiteNames" && exit 0
else
	siteList=$inFileBase
fi

# Process GLUE data, one site at a time and calculate the installed capacity values
for entry in `echo "$siteList"` # for each site entry in sites.txt file
do # do the following
	sitenum=$[$sitenum+1]
	[ $fqdnFlag -eq 0 ] && site=`echo $entry|cut -d',' -f1` && fqdn=`echo $entry|cut -d',' -f2` # get site's FQDN
	[ $fqdnFlag -eq 1 ] && fqdn="$inFileBase" && site=`cat $INSTALL_DIR/conf/sites.txt|grep -i $fqdn|cut -d, -f1`
	site_ll=${site}_ll # create the dynamic variable that represents the lower limit for the site's installed capacity
	site_ul=${site}_ul # create the dynamic variable that represents the upper limit for the site's installed capa city
	[ ! -z $verbose ] && [ $verbose -eq 1 ] && echo $site
	if [ $fqdnFlag -eq 0 ]; then
		[ ! -z $verbose ] && [ $verbose -eq 1 ] && echo "curl http://is.grid.iu.edu/data/cemon_transitory/$fqdn?which=$site -stderr /dev/null|egrep -i \"GlueSubClusterName|GlueSubClusterLogicalCPUs|GlueHostBenchMarkSI00|GlueHostProcessorClockSpeed|GlueHostProcessorModel|InstalledOnlineCapacity|InstalledNearlineCapacity|sponsor\""
		# Execute the curl command to get the BDII GLUE data for the site
		glue=`curl http://is.grid.iu.edu/data/cemon_transitory/$fqdn?which=$site -stderr /dev/null|egrep -i "GlueSubClusterName|GlueSubClusterLogicalCPUs|GlueHostBenchMarkSI00|GlueHostProcessorClockSpeed|GlueHostProcessorModel|InstalledOnlineCapacity|InstalledNearlineCapacity|sponsor" 2>>$logFile`
		curlExitCode=$?
		[ ! -z $verbose ] && [ $verbose -eq 1 ] && echo curl exit code is $curlExitCode
		# If curl failed for some reason, display the error and continue to the next site
		[ $curlExitCode -ne 0 ] && echo "Failed to get glue data for $site. Error is " >>$logFile && cat /tmp/curlError.txt >>$logFile && continue
	else
		glue=`cat $inFile|egrep -i "GlueSubClusterName|GlueSubClusterLogicalCPUs|GlueHostBenchMarkSI00|GlueHostProcessorClockSpeed|GlueHostProcessorModel|InstalledOnlineCapacity|InstalledNearlineCapacity|sponsor"`
		#echo site: $site, fqdn: $fqdn, adjust: $adjust 
	fi
	# process the BDII GLUE data using awk one line at a time
	#echo "$glue"
	#exit
	echo "$glue"|awk ' # Note the double quotes in "$glue". This is essential to preserve the end of line characters in the data
	BEGIN {
		# Initialize all needed variables once at the Beginning
		IGNORECASE=1 # do not differentiate between upper and lower case in the input data 
		kindx=0 # index for ksi2k array
		nindx=0 # index for logicalCpu count array
		pmindx=0 # index for processor model array
		allSites="'$allSites'" # process all sites - default is only cms and atlas sites
		verbose="'$verbose'" # verbose output or not
		includeSite=0 # variable to flag if the installed capacity of a site needs to be included or not 
		if(allSites==1) includeSite=1 # include this particular site
		ic=0 # adjusted installed capacity
		ic_original=0 # calculated installed capacity
		ic_adjustp=0 # % by which the ic data need to be adjusted to fit within the bounds
		osc=0 # online storage capacity
		nsc=0 # nearline storage capacity
	}
	{
		if(verbose==1) print "'$site' " $0
		# If the site sponsors usatlas or cms VOs get the sponsor % for atlas or cms. This is a single value for the entire site i.e. it is shared across all sub-clusters. If the site does not support atlas or cms VOs then the sponsorship % is taken as 0
		if($1~/GlueSiteSponsor/ && ($0~/usatlas/ || $0~/cms/))
		{
			includeSite=1 # include the site in the report
			for(i=2;i<=NF;++i) # for each field
			{
				if($i~/atlas/ || $i~/cms/) # filter out the fields matching atlas or cms
				{
					sub(/,/,"",$0)
					split($i,sponsor,":") # split the data using : as delimiter and store the results in the array sponsor
					sub(/,/,"",sponsor[2]) # sponsor[2] contains the percentage value. Remove the , chacacter if any
					if(sponsor[2]=="") # if sponsor percentage is not explicitly given
					{
						sponsor[2]=100; # set it to 100% of the atlas or cms VO
					}
				}
			}
		}
		# Extract the KSI2K value for the processor model of a particular sub-cluster
		if($1~/GlueHostProcessorModel/)
		{
			split($0,pm,":")
			sub(/ /,"",pm[2])
			pmindx++
			pmodel[pmindx]=pm[2] # extract the processor model
			if(ksi2k_lookup[pmodel[pmindx]]=="") # if the processor has not been already looked-up
			{
        			cmd="cat ""'$gipconf'""|grep \"\\\""pmodel[pmindx]"\\\"\"|head -1|cut -d : -f2|cut -d , -f1" # critical: command to lookup the ksi2k value for the processor from the gip configuration file
				if(verbose==1) print "'$site' looking up: " cmd
        			cmd|getline ksi2k_lookup[pmodel[pmindx]] # Execute the command and catch the value to the ksi2k_lookup[...] associative array
        			sub(/\(/,"",ksi2k_lookup[pmodel[pmindx]]) # Remove the ( chacacter
        			sub(/ /,"",ksi2k_lookup[pmodel[pmindx]]) # Remove any space. Exact lookup value is available at this point
				# if ksi2k lookup value for processor model is not found, print a WARNING if verbose output is indicated. Default value provided by GIP will be used for calculation purposes. 
				#if(verbose==1 && ksi2k_lookup[pmodel[pmindx]]=="")
				if(ksi2k_lookup[pmodel[pmindx]]=="")
				{
					print "'$site' 1. WARNING!!! No lookup match found for \""pmodel[pmindx]"\"" >> "'$logFile'"
				}
			}
		}
		# Get the default ksi2k value for processor as provided by GIP. The default will be replaced by the ksi2k lookup value found above (if available)
		if($1~/GlueHostBenchmarkSI00/)
		{	
			split($0,bm,":")
			kindx++
			ksi2k[kindx]=bm[2]
        		sub(/ /,"",ksi2k[kindx])
		}
		# Get the number of logical CPUs from the GLUE data
		if($1~/GlueSubClusterLogicalCPUs/)
		{	
			split($0,cpus,":")
			nindx++
			logicalCpus[nindx]=cpus[2]
		}
		# calculate online storage capacity
		if($2~/InstalledOnlineCapacity/)
		{	
			split($2,oscArr,"=")
			osc+=oscArr[2]
		}
		# calculate nearline storage capacity
		if($2~/InstalledNearlineCapacity/)
		{	
			split($2,nscArr,"=")
			nsc+=nscArr[2]
		}
	}
	# post-processing to calculate the installed capacity value
	END {
		# print the formatted header once if the format option if specified
		if("'$format'"==1 && verbose!=1 && "'$sitenum'"==1)
		{
			print "=============================================================="
			printf("%-20s %-10s %-10s %-10s %-10s\n","SITE","IC_CALC","IC_SS","DIFF","%DIFF")
			print "=============================================================="
		}
		# print the csv header once if the csv option if specified
		else if("'$csv'"==1 && verbose!=1 && "'$sitenum'"==1)
			print "SITE,IC_SS,IC_CALC,DIFF,%DIFF"
		if(verbose==1) 
			print " "
		# Convert the sponsorship percentage into a ratio 
		sponsor[2]/=100;
		#print "site: '$site',includeSite: "includeSite
		# for the BDII GLUE data to be valid the total # of occurances across all sub-clusters of ksi2k, logicalCPUs and processor model should be equal
		if(kindx==nindx && nindx==pmindx && includeSite==1)
		{
			# Any of kindx, nindx or pmindx could be used to loop through the gathered values for processing
			for(i=1;i<=kindx;i++)
			{
				if(verbose==1) print " "
				if(verbose==1) print "'$site' sub cluster # "i
				if(verbose==1) print "'$site' " logicalCpus[i]" logical CPUs"
				# If benchmark GIP ksi2k for a CPU model has a standard value
				if((ksi2k[i]==400 || ksi2k[i]==800 || ksi2k[i]==2000))
				{
					if(verbose==1) print "'$site' processor model: "pmodel[i]
					# If the lookup value for that processor model is available
					if(ksi2k_lookup[pmodel[i]]!="" && ksi2k_lookup[pmodel[i]]!=0)
					{
						if(verbose==1) print "'$site' ksi2k original:"ksi2k[i]", ksi2k lookup:"ksi2k_lookup[pmodel[i]]
						# Replace the GIP standard ksi2k value by the lookup value
						ksi2k[i]=ksi2k_lookup[pmodel[i]]
					}
					else
						if(verbose==1) print "'$site' 2. No lookup match found for \""pmodel[i]"\""
				}
				# calculate the total installed capacity for the cluster by summing up the installed capacity for a sub-cluster. 
				ic+=ksi2k[i]*logicalCpus[i]
				if(verbose==1) print "'$site' ic+= "ksi2k[i]" * "logicalCpus[i]
				if(verbose==1) print "'$site' " ic
				if(verbose==1) print " "
			}
			if(verbose==1) print "'$site' ic*= "sponsor[2]/(1000)" = "ic "*" sponsor[2]/(1000)
			# Weight the installed capacity by the fraction of the sponsorship and divide it by 1000 as indicated in the installed capacity document
			ic*=sponsor[2]/(1000)
			ss="'$[$site]'"	
			# print out the calculated installed capacity value and its comparison with the values maintained by the T2 co-ordinators (as sourced from the t2.sh file). Also limit the installed capacity values within the upper and lower bounds
			if(ss!=0 || allSites==1) # If value maintained by the T2 co-ordinators is available in the t2.sh file
			{
				ll='$[$site_ll]' # get the lower bound
				ul='$[$site_ul]' # get the upper bound
				if(ll!=0 && ul!=0 && ll<=ul) # If the bounds are valid and ic is outside of the bounds 
				{
					# limit ic within bounds
					if(ic < ll)
					{
						# Find the % difference (the BDII data of the sub-clusters will be propotionally adjusted according to this %)
						if(ic!=0) # avoid division by 0
							ic_adjustp = (ll-ic)*100/ic  # This will be a +ve %value
						else
							ic_adjustp = 100
						ic_original=ic
						ic=ll
					}
					else if(ic > ul)
					{
						# Find the % difference (this will be a -ve %value)
						if(ic!=0) # avoid division by 0
							ic_adjustp = (ul-ic)*100/ic
						else
							ic_adjustp = -100
						ic_original=ic
						ic=ul
					}
				}
				# print formatted or csv values for ic
				if(ic!=0)
				{
					if("'$format'"==1)
					{
						if(ic_original!=0)
							printf("%-20s %-d(%-d) %-10d %-10d %-10d","'$site'",ic,ic_original,ss,ic-ss,(ic-ss)*100/ic)
						else
							printf("%-20s %-10d %-10d %-10d %-10d","'$site'",ic,ss,ic-ss,(ic-ss)*100/ic)
					}
					if(verbose==1)
						print
					if("'$csv'"==1)
						printf("%s,%d,%d,%d,%d","'$site'",ic,ss,ic-ss,(ic-ss)*100/ic)
				}
				else
				{
					if("'$format'"==1)
						printf("%-20s %-10d %-10d %-10d","'$site'",ic,ss,ic-ss)
					if(verbose==1)
						print
					if("'$csv'"==1)
						printf("%-s,%d,%d,%d","'$site'",ic,ss,ic-ss)
				}
				if("'$adjust'"==1)
				{
					#print "'$site'",ic,ll,ul,ic_adjustp,kindx 
					# print the % by which sub-cluster information needs to be adjusted. Also print the number of sub-clusters. OR may be this could be combined into one variable
					#printf("%-20s %d %d\n","'$site'",ic_adjustp,kindx) 
					# ic_adjustp/=kindx # This is wrong!!! If ic needs to be adjusted by a %value, then is corresponding to every sub-cluster needs to be adjusted by the same %value and not by (%value/number of sub-clusters)!
					if(ic_adjustp != 0)
						#printf("%-20s %d\n","'$site'",ic_adjustp) 
						printf("%d\n",ic_adjustp) 
				}
				else	
					print " "
				if(adjust==1 && (osc > 0 || nsc > 0))
					print "OSC: ",osc," NSC: ", nsc
			}
			if(verbose==1) print " "
			if(verbose==1) print "*****************************************************"
		}
		# if the index counts for different attributes do not match then something is wrong with the GLUE data 
		else if(includeSite == 1)
			print "'$site' GLUE data for "'$site'" seems to be invalid. "
	}'
done

[ $format -eq 1 ] && echo "=============================================================="
[ $html -eq 1 ] && echo "Last updated at `date`"
[ $html -eq 1 ] && echo "</pre>"
[ ! -s $logFile ] && rm -f $logFile
