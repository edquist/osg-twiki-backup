#!/bin/sh

#Author: Karthik
#Date: Tue, March 3rd 2009
#Purpose: Script to print BDII data adjusted according to the adjustments needed in the installed capacity for limiting it within bounds. This script reads the BDII GLUE data (from the BDII webpage) for different T2 sites and then calculates the percentage by which the installed capacity of a site needs to be adjusted to be within the limits specified in the configuration files (ult2.sh, llt2.sh) and then accordingly adjusts and prints the BDII data 
#Pre-requisites: curl (should be executable from command line)
# Input data needed
#		sites.txt - file containing the list of sites along with their FQDN
#
#########################################################################################################

if [ -z $INSTALL_DIR ]; then
	echo "ERROR!!! INSTALL_DIR not set." 
	echo "Set the installation directory as shown below and try again."
	echo "export INSTALL_DIR=/absolute/path/to/installation/directory"
	exit 2
fi

yyyymmdd=`$INSTALL_DIR/helper/yyyymmdd.sh` # date and time stamp to be used for the script's log file
logFile="$INSTALL_DIR/log/ic-$yyyymmdd.log"

# usage routine to display usage if the user mis-types options or indicates help using the help flag
usage() {
	echo "Usage: $0 <indir> <outdir>"
	echo "indir is the input directory containing the BDII files to read data from."
	echo "outdir is the output directory to which the adjusted BDII data needs to be written."
}

[ $# -ne 2 ] && usage && exit 2

inDir=$1
[ ! -d $inDir ] && echo "ERROR!!! Input directory $inDir does not exist. " && exit 2
outDir=$2
[ ! -d $outDir ] && echo "ERROR!!! Output directory $outDir does not exist. " && exit 2

[ $inDir == $outDir ] && echo "ERROR!!! Input directory and output directory cannot be the same!" && exit 2

gipconf=$INSTALL_DIR/conf/gip.conf # gip configuration file - used to lookup KSI2K values for various processor models

#########################################################################################################

# Process BDII data, one site at a time and calculate the installed capacity values
for file in `ls $inDir` # for each site entry in sites.txt file
do # do the following
	inFile=$inDir/$file
	[ ! -s $inFile ] && echo "WARNING!!! File $inFile is empty" && continue
	outFile=$outDir/$file
	site=`cat $INSTALL_DIR/conf/sites.txt|grep -i $file|cut -d , -f1`
	# CRITICAL: get the % by which the sub-cluster bdii data need to be adjusted (applicable if the ic of the site falls out of the bounds) if any. This value will be used at the later part of the script to adjust the BDII data before outputting the BDII data
	#adjustp=`$INSTALL_DIR/helper/ic.sh -adjust -site $site|awk '{print $2}'`
	adjustp=`$INSTALL_DIR/helper/ic.sh -adjust -fqdn $inFile`
	[ -z $adjustp ] && adjustp=0
	# Get the BDII GLUE data for the site
	glue=`cat $inFile`
	# Process the BDII GLUE data using awk one line at a time
	echo "$glue"|awk ' # Note the double quotes in "$glue". This is essential to preserve the end of line characters in the data
	BEGIN {
		# Initialize all needed variables once at the Beginning
		IGNORECASE=1 # do not differentiate between upper and lower case in the input data 
		kindx=0 # index for ksi2k array
		nindx=0 # index for logicalCpu count array
		pmindx=0 # index for processor model array
	}
	{
		# In this section we go through the BDII data line by line to analyze the data
		# If the site sponsors usatlas or cms VOs get the sponsor % for atlas or cms. This is a single value for the entire site i.e. it is shared across all sub-clusters. If the site does not support atlas or cms VOs then the sponsorship % is taken as 0
		if($1~/GlueSiteSponsor/ && ($0~/usatlas/ || $0~/cms/))
		{
			includeSite=1 # include the site in the report
			for(i=2;i<=NF;++i) # for each field
			{
				if($i~/atlas/ || $i~/cms/) # filter out the fields matching atlas or cms
				{
					sub(/,/,"",$0)
					split($i,sponsor,":") # split the data using : as delimiter and store the results in the array sponsor
					sub(/,/,"",sponsor[2]) # sponsor[2] contains the percentage value. Remove the , chacacter if any
					if(sponsor[2]=="") # if sponsor percentage is not explicitly given
					{
						sponsor[2]=100; # set it to 100% of the atlas or cms VO
					}
				}
			}
		}
		# Extract the KSI2K value for the processor model of a particular sub-cluster
		if($1~/GlueHostProcessorModel/)
		{
			split($0,pm,":")
			sub(/ /,"",pm[2])
			pmindx++
			pmodel[pmindx]=pm[2] # extract the processor model
			if(ksi2k_lookup[pmodel[pmindx]]=="") # if the processor has not been already looked-up
			{
        			cmd="cat ""'$gipconf'""|grep \"\\\""pmodel[pmindx]"\\\"\"|head -1|cut -d : -f2|cut -d , -f1" # critical: command to lookup the ksi2k value for the processor from the gip configuration file
        			cmd|getline ksi2k_lookup[pmodel[pmindx]] # Execute the command and catch the value to the ksi2k_lookup[...] associative array
        			sub(/\(/,"",ksi2k_lookup[pmodel[pmindx]]) # Remove the ( chacacter
        			sub(/ /,"",ksi2k_lookup[pmodel[pmindx]]) # Remove any space. Exact lookup value is available at this point
			}
		}
		# Get the default ksi2k value for processor as provided by GIP. The default will be replaced by the ksi2k lookup value found above (if available)
		if($1~/GlueHostBenchmarkSI00/)
		{	
			split($0,bm,":")
			kindx++
			ksi2k[kindx]=bm[2]
        		sub(/ /,"",ksi2k[kindx])
		}
		# Get the number of logical CPUs from the GLUE data
		if($1~/GlueSubClusterLogicalCPUs/)
		{	
			split($0,cpus,":")
			nindx++
			logicalCpus[nindx]=cpus[2]
		}
		# CRITICAL: collect all the data in an array. This will be conveniently used for post-processing (adjust the BDII data if appropriate, so that it will limit the installed capacity value within the bounds) in the END section.
		bdiiIndx++
		bdii[bdiiIndx]=$0
	}
	# post-processing to print out the adjusted bdii/glue data 
	END {
		for(i=1;i<=bdiiIndx;i++)
		{
			# print looked up GlueHostBenchmarkSI00 if available, instead of the default values
			if(bdii[i]~/GlueHostBenchmarkSI00/)
			{
				split(bdii[i],bm_adjust,":")
				kindx_adjust++
				ksi2k_adjust[kindx_adjust]=bm_adjust[2]
        			sub(/ /,"",ksi2k_adjust[kindx_adjust])
        			if(ksi2k_lookup[pmodel[kindx_adjust]] > 0) # lookup value available
					print "GlueHostBenchmarkSI00: "ksi2k_lookup[pmodel[kindx_adjust]] > "'$outFile'"
				else # lookup value not available
					print bdii[i] > "'$outFile'"
			}
			# adjust the number of physical and logical CPUs according to the %value (adjustp) by which the installed capacity needs to be adjusted to stay within the bounds
			else if(bdii[i]~/GlueSubClusterLogicalCPUs/ || bdii[i]~/GlueSubClusterPhysicalCPUs/)
			{
				cpuCount_adjust[1]=""
				cpuCount_adjust[2]=""
				if("'$adjustp'" != 0) # needs to be adjusted 
				{
					split(bdii[i],cpuCount_adjust,": ")
        				sub(/ /,"",cpuCount_adjust[2])
					new_cpu_count = cpuCount_adjust[2]*(1+"'$adjustp'"/100)
					if(new_cpu_count < 0)
						new_cpu_count=0
					printf("%s: %d\n",cpuCount_adjust[1],new_cpu_count) > "'$outFile'"
				}
				else # does not need to be adjusted 
					print bdii[i] > "'$outFile'"
			}
			else # other bdii data
				print bdii[i]  > "'$outFile'" # print unaltered
		}
	}'
done
[ -r $logFile ] && [ ! -s $logFile ] && rm -f $logFile
