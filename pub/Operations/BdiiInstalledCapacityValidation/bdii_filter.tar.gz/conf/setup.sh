#!/bin/sh

# Project installation directory
#export INSTALL_DIR=/home/karunach/velai/osg/installed_capacity/scripts/ic/publish

# Lower Limit (ll) values for installed computing capacity for T2 sites
# Needs updated values (current values are arbitary)
# ATLAS
export AGLT2_ll=3000
export HU_ATLAS_T2_ll=13090
export BU_ATLAS_Tier2_ll=1376
export UC_ATLAS_MWT2_ll=117
export IU_OSG_ll=215
export MWT2_IU_ll=1780
export MWT2_UC_ll=2660
export OU_OCHEP_SWT2_ll=465
export OU_OSCER_ATLAS_ll=13871
export WT2_ll=3743
export BNL_ATLAS_1_ll=6120
export SWT2_CPB_ll=1383
export UTA_SWT2_ll=494
# CMS
export MIT_CMS_ll=2256
export Nebraska_ll=1600
export UCSDT2_ll=1788
export CIT_CMS_T2_ll=1200

# Upper Limit (ul) values for installed computing capacity for T2 sites
# Needs updated values. Current values are aribtary
# ATLAS
export AGLT2_ul=4000
export HU_ATLAS_T2_ul=13090
export BU_ATLAS_Tier2_ul=1376
export UC_ATLAS_MWT2_ul=117
export IU_OSG_ul=215
export MWT2_IU_ul=1780
export MWT2_UC_ul=2660
export OU_OCHEP_SWT2_ul=465
export OU_OSCER_ATLAS_ul=13871
export WT2_ul=3743
export BNL_ATLAS_1_ul=6120
export SWT2_CPB_ul=1383
export UTA_SWT2_ul=494
# CMS
export MIT_CMS_ul=2256
export Nebraska_ul=1600
export UCSDT2_ul=1788
export CIT_CMS_T2_ul=1200

# Values maintained by T2 co-ordinators
# ATLAS
export AGLT2=4678
export HU_ATLAS_T2=13090
export BU_ATLAS_Tier2=1376
export UC_ATLAS_MWT2=117
export IU_OSG=215
export MWT2_IU=1780
export MWT2_UC=2660
export OU_OCHEP_SWT2=465
export OU_OSCER_ATLAS=13871
export WT2=3743
export BNL_ATLAS_1=6120
export SWT2_CPB=1383
export UTA_SWT2=494
# CMS
export MIT_CMS=2256
export Nebraska=1600
export UCSDT2=1788
export CIT_CMS_T2=1200
