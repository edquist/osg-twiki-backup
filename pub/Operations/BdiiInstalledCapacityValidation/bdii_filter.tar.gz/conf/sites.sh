#!/bin/sh
# extract ic site names and fqdn from the entries at http://is.grid.iu.edu/cgi-bin/status.cgi
cat bdii.txt|awk '
{
	if($6!="N/A")
	{
		print $1","$2;
	}
}'
